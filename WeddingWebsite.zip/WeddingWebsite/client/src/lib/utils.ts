import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Custom colors matching the design reference
export const colors = {
  gold: '#d4b78f',
  goldDark: '#c9a57c',
  cream: '#f8f5f0',
  creamLight: '#faf7f2',
  textDark: '#333333'
};

// Format date to string (e.g., "15 Giugno 2024")
export function formatDate(date: Date): string {
  const months = [
    'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno',
    'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'
  ];
  
  return `${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
}

// Mapping object for RSVP attendance options
export const attendanceOptions = {
  ceremony: "Cerimonia",
  reception: "Ricevimento",
  party: "Festa serale"
};

// Format time (e.g., "15:00")
export function formatTime(date: Date): string {
  return date.toLocaleTimeString('it-IT', { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: false
  });
}
