import ScrollAnimator from "./ScrollAnimator";

export default function OurStory() {
  return (
    <section id="storia" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <ScrollAnimator>
          <div className="text-center mb-16">
            <h2 className="font-cormorant text-4xl md:text-5xl mb-4">
              La Nostra Storia
            </h2>
            <div className="w-20 h-0.5 bg-primary mx-auto"></div>
          </div>
        </ScrollAnimator>

        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-center mb-16">
            <ScrollAnimator>
              <div className="md:w-1/2">
                <img
                  src="https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                  alt="Primo incontro"
                  className="w-full h-80 object-cover shadow-lg rounded-lg md:rounded-br-none md:rounded-tr-none"
                />
              </div>
            </ScrollAnimator>
            <ScrollAnimator>
              <div className="md:w-1/2 bg-[#f8f5f0] p-8 md:-ml-8 mt-6 md:mt-14 relative z-10 shadow-lg rounded-lg">
                <h3 className="font-cormorant text-2xl mb-4">
                  Come Ci Siamo Conosciuti
                </h3>
                <p className="text-gray-700 mb-4">
                  Il nostro primo incontro è avvenuto in una caffetteria nel
                  centro di Napoli. Fabio era seduto al tavolo accanto leggendo
                  il suo libro preferito, lo stesso che Denise aveva appena
                  terminato. Una conversazione su quel libro è stato l'inizio di
                  tutto.
                </p>
                <p className="text-gray-700">
                  Da quel giorno di settembre 2020, ogni momento insieme è stato
                  speciale, e non vediamo l'ora di iniziare il nostro viaggio
                  come marito e moglie.
                </p>
              </div>
            </ScrollAnimator>
          </div>

          <div className="flex flex-col md:flex-row-reverse items-center">
            <ScrollAnimator>
              <div className="md:w-1/2">
                <img
                  src="https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                  alt="La proposta"
                  className="w-full h-80 object-cover shadow-lg rounded-lg md:rounded-bl-none md:rounded-tl-none"
                />
              </div>
            </ScrollAnimator>
            <ScrollAnimator>
              <div className="md:w-1/2 bg-[#f8f5f0] p-8 md:-mr-8 mt-6 md:mt-14 relative z-10 shadow-lg rounded-lg">
                <h3 className="font-cormorant text-2xl mb-4">La Proposta</h3>
                <p className="text-gray-700 mb-4">
                  Dopo tre anni insieme, durante una vacanza sulla costa
                  amalfitana, Fabio ha organizzato una cena a lume di candela
                  con vista sul mare. Mentre il sole tramontava, si è
                  inginocchiato e ha chiesto a Denise di sposarlo.
                </p>
                <p className="text-gray-700">
                  Con le lacrime agli occhi e il cuore pieno di gioia, Denise ha
                  detto sì, dando inizio ai preparativi per il nostro giorno
                  speciale.
                </p>
              </div>
            </ScrollAnimator>
          </div>
        </div>
      </div>
    </section>
  );
}
