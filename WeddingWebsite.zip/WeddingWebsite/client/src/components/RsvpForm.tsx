import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle2, AlertCircle } from "lucide-react";
import ScrollAnimator from "./ScrollAnimator";

// Form schema with validation
const rsvpFormSchema = z.object({
  name: z.string().min(2, { message: "Il nome è richiesto" }),
  email: z.string().email({ message: "Email non valida" }),
  phone: z.string().optional(),
  guests: z.string().min(1, { message: "Seleziona il numero di ospiti" }),
  attending: z
    .array(z.string())
    .min(1, { message: "Seleziona almeno un evento a cui parteciperai" }),
  dietary: z.string().optional(),
  message: z.string().optional(),
});

type RsvpFormValues = z.infer<typeof rsvpFormSchema>;

export default function RsvpForm() {
  const [formSuccess, setFormSuccess] = useState(false);
  const [formError, setFormError] = useState(false);

  const form = useForm<RsvpFormValues>({
    resolver: zodResolver(rsvpFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      guests: "",
      attending: [],
      dietary: "",
      message: "",
    },
  });

  const attendingOptions = [
    { id: "ceremony", label: "Cerimonia" },
    { id: "reception", label: "Ricevimento" },
    { id: "party", label: "Festa serale" },
  ];

  // The mutation to submit RSVP
  const mutation = useMutation({
    mutationFn: (values: RsvpFormValues) => {
      return apiRequest("POST", "/api/rsvp", values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rsvp"] });
      setFormSuccess(true);
      setFormError(false);
      form.reset();
      
      // Hide success message after 5 seconds
      setTimeout(() => {
        setFormSuccess(false);
      }, 5000);
    },
    onError: () => {
      setFormError(true);
      setFormSuccess(false);
    },
  });

  // Handle form submission
  function onSubmit(values: RsvpFormValues) {
    mutation.mutate(values);
  }

  return (
    <section id="rsvp" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <ScrollAnimator>
          <div className="text-center mb-16">
            <h2 className="font-cormorant text-4xl md:text-5xl mb-4">
              Conferma la tua Presenza
            </h2>
            <div className="w-20 h-0.5 bg-primary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-gray-700">
              Ti preghiamo di confermare la tua presenza entro il 15 Novembre 2025.
            </p>
          </div>
        </ScrollAnimator>

        <div className="max-w-3xl mx-auto">
          <ScrollAnimator>
            <Card className="bg-white p-8 rounded-lg shadow-lg">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            Nome e Cognome <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Inserisci il tuo nome"
                              {...field}
                              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            Email <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="La tua email"
                              {...field}
                              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Telefono</FormLabel>
                          <FormControl>
                            <Input
                              type="tel"
                              placeholder="Numero di telefono"
                              {...field}
                              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="guests"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            Numero di Ospiti{" "}
                            <span className="text-red-500">*</span>
                          </FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                                <SelectValue placeholder="Seleziona" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="1">1</SelectItem>
                              <SelectItem value="2">2</SelectItem>
                              <SelectItem value="3">3</SelectItem>
                              <SelectItem value="4">4</SelectItem>
                              <SelectItem value="5">5</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="attending"
                    render={() => (
                      <FormItem>
                        <div className="mb-2">
                          <FormLabel>
                            Parteciperò a: <span className="text-red-500">*</span>
                          </FormLabel>
                        </div>
                        <div className="space-y-2">
                          {attendingOptions.map((option) => (
                            <FormField
                              key={option.id}
                              control={form.control}
                              name="attending"
                              render={({ field }) => {
                                return (
                                  <FormItem
                                    key={option.id}
                                    className="flex flex-row items-start space-x-2 space-y-0"
                                  >
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value?.includes(option.id)}
                                        onCheckedChange={(checked) => {
                                          return checked
                                            ? field.onChange([
                                                ...field.value,
                                                option.id,
                                              ])
                                            : field.onChange(
                                                field.value?.filter(
                                                  (value) => value !== option.id
                                                )
                                              );
                                        }}
                                      />
                                    </FormControl>
                                    <FormLabel className="text-sm font-normal cursor-pointer">
                                      {option.label}
                                    </FormLabel>
                                  </FormItem>
                                );
                              }}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dietary"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Restrizioni Alimentari o Allergie</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Indica eventuali allergie o preferenze alimentari"
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Messaggio per gli Sposi</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Scrivi un messaggio per gli sposi"
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="text-center pt-4">
                    <Button
                      type="submit"
                      className="px-8 py-6 bg-primary text-white font-medium uppercase tracking-wide text-sm transition duration-300 hover:bg-[#c9a57c]"
                      disabled={mutation.isPending}
                    >
                      {mutation.isPending
                        ? "Invio in corso..."
                        : "Conferma Presenza"}
                    </Button>
                  </div>
                </form>
              </Form>
            </Card>
          </ScrollAnimator>

          {formSuccess && (
            <Alert className="mt-4 bg-green-100 text-green-700 animate-in fade-in duration-300">
              <CheckCircle2 className="h-4 w-4" />
              <AlertDescription>
                Grazie per aver confermato la tua presenza! Non vediamo l'ora di
                festeggiare con te.
              </AlertDescription>
            </Alert>
          )}

          {formError && (
            <Alert className="mt-4 bg-red-100 text-red-700 animate-in fade-in duration-300">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Si è verificato un errore durante l'invio del modulo. Per favore,
                riprova più tardi o contattaci direttamente.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </div>
    </section>
  );
}
