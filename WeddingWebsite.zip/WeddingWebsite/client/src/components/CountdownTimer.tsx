import { useState, useEffect } from "react";

type CountdownTimerProps = {
  targetDate: string;
};

type TimeLeft = {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
};

export default function CountdownTimer({ targetDate }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const weddingDate = new Date(targetDate).getTime();

    const updateCountdown = () => {
      const now = new Date().getTime();
      const distance = weddingDate - now;

      if (distance < 0) {
        // If the date has passed
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
        });
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor(
        (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
      );
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, [targetDate]);

  const formatNumber = (num: number): string => {
    return num.toString().padStart(2, "0");
  };

  return (
    <div className="flex justify-center space-x-6 md:space-x-10">
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-cormorant font-light text-white">
          {formatNumber(timeLeft.days)}
        </div>
        <div className="text-xs uppercase tracking-wider text-white mt-1">
          Giorni
        </div>
      </div>
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-cormorant font-light text-white">
          {formatNumber(timeLeft.hours)}
        </div>
        <div className="text-xs uppercase tracking-wider text-white mt-1">
          Ore
        </div>
      </div>
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-cormorant font-light text-white">
          {formatNumber(timeLeft.minutes)}
        </div>
        <div className="text-xs uppercase tracking-wider text-white mt-1">
          Minuti
        </div>
      </div>
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-cormorant font-light text-white">
          {formatNumber(timeLeft.seconds)}
        </div>
        <div className="text-xs uppercase tracking-wider text-white mt-1">
          Secondi
        </div>
      </div>
    </div>
  );
}
