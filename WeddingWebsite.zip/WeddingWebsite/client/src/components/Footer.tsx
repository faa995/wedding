import { Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="py-10 bg-white">
      <div className="container mx-auto px-4 text-center">
        <div className="mb-6">
          <h2 className="font-great-vibes text-[#c9a57c] text-3xl mb-2">
            Fabio & Denise
          </h2>
          <p className="text-gray-700">21 Dicembre 2025</p>
        </div>

        <div className="w-32 h-0.5 bg-[#c9a57c] opacity-30 mx-auto mb-6"></div>

        <div className="mb-6">
          <p className="text-gray-700 mb-2">Per qualsiasi domanda, contattaci:</p>
          <a
            href="mailto:fabioedenise@example.com"
            className="text-primary hover:text-[#c9a57c] transition-colors inline-flex items-center"
          >
            <Mail className="mr-2 h-4 w-4" />
            <span>fabioedenise@example.com</span>
          </a>
        </div>

        <p className="text-gray-500 text-sm">
          &copy; {new Date().getFullYear()} Fabio & Denise - Il Nostro Matrimonio
        </p>
      </div>
    </footer>
  );
}
