import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Gift, PlaneTakeoff } from "lucide-react";
import ScrollAnimator from "./ScrollAnimator";

export default function Registry() {
  return (
    <section id="regali" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <ScrollAnimator>
          <div className="text-center mb-16">
            <h2 className="font-cormorant text-4xl md:text-5xl mb-4">
              Lista Nozze
            </h2>
            <div className="w-20 h-0.5 bg-primary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-gray-700">
              La vostra presenza è il regalo più prezioso, ma se desiderate farci un
              dono, ecco alcune idee.
            </p>
          </div>
        </ScrollAnimator>

        <ScrollAnimator>
          <Card className="max-w-3xl mx-auto bg-[#f8f5f0] p-8 rounded-lg shadow-md">
            <p className="text-center text-gray-700 mb-8">
              Abbiamo creato una lista nozze online dove potrete trovare alcuni
              oggetti che ci piacerebbe ricevere per iniziare questa nuova avventura
              insieme. In alternativa, un contributo per il nostro viaggio di nozze
              in Thailandia sarebbe molto apprezzato.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
              <Card className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="w-16 h-16 rounded-full gold-gradient flex items-center justify-center mx-auto mb-4">
                  <Gift className="text-white" />
                </div>
                <h3 className="font-cormorant text-xl mb-3">Lista Nozze</h3>
                <p className="text-gray-700 mb-4">
                  Visita la nostra lista nozze online per scegliere tra vari oggetti
                  per la nostra nuova casa.
                </p>
                <Button
                  variant="outline"
                  className="border-2 border-primary text-primary hover:bg-primary hover:text-white"
                >
                  Visualizza Lista
                </Button>
              </Card>

              <Card className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="w-16 h-16 rounded-full gold-gradient flex items-center justify-center mx-auto mb-4">
                  <PlaneTakeoff className="text-white" />
                </div>
                <h3 className="font-cormorant text-xl mb-3">Luna di Miele</h3>
                <p className="text-gray-700 mb-4">
                  Contribuisci al nostro viaggio di nozze alle Maldive, regalandoci
                  un'esperienza indimenticabile.
                </p>
                <Button
                  variant="outline"
                  className="border-2 border-primary text-primary hover:bg-primary hover:text-white"
                >
                  Contribuisci
                </Button>
              </Card>
            </div>

            <div className="text-center">
              <h3 className="font-cormorant text-xl mb-4">Informazioni Bancarie</h3>
              <div className="bg-white p-4 rounded-lg inline-block mx-auto">
                <p className="text-gray-700 mb-1">
                  <span className="font-medium">Intestatari:</span> Fabio Esposito e
                  Denise Marino
                </p>
                <p className="text-gray-700 mb-1">
                  <span className="font-medium">IBAN:</span>{" "}
                  IT12A3456789012345678901234
                </p>
                <p className="text-gray-700">
                  <span className="font-medium">Causale:</span> Regalo di nozze -
                  [Vostro nome]
                </p>
              </div>
            </div>
          </Card>
        </ScrollAnimator>
      </div>
    </section>
  );
}
