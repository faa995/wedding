import { Card } from "@/components/ui/card";
import { MapPin, Car, Bed, Star } from "lucide-react";
import ScrollAnimator from "./ScrollAnimator";

export default function TravelInfo() {
  return (
    <section id="viaggio" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <ScrollAnimator>
          <div className="text-center mb-16">
            <h2 className="font-cormorant text-4xl md:text-5xl mb-4">
              Informazioni di Viaggio
            </h2>
            <div className="w-20 h-0.5 bg-primary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-gray-700">
              Tutto ciò che c'è da sapere per arrivare e soggiornare per il nostro
              matrimonio.
            </p>
          </div>
        </ScrollAnimator>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <ScrollAnimator>
            <Card className="bg-white p-8 rounded-lg shadow-lg">
              <h3 className="font-cormorant text-2xl mb-6 flex items-center">
                <MapPin className="text-primary mr-3 h-5 w-5" />
                Sede dell'Evento
              </h3>

              <div className="mb-6">
                <h4 className="font-medium text-lg mb-2">Tenuta Donna Fausta</h4>
                <p className="text-gray-700 mb-2">
                  Via Castello, 81051 Roccaromana CE
                </p>
                <p className="text-gray-700 mb-4">
                  La tenuta si trova a circa 50 minuti di auto dal centro di Napoli,
                  immersa nelle colline casertane.
                </p>

                <div className="bg-secondary p-4 rounded-md">
                  <p className="text-gray-700 mb-2">
                    <span className="font-medium">Coordinate GPS:</span> 41.2814°
                    N, 14.3161° E
                  </p>
                  <a
                    href="https://maps.google.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:text-[#c9a57c] transition-colors inline-flex items-center"
                  >
                    <span>Apri su Google Maps</span>
                    <MapPin className="ml-2 h-4 w-4" />
                  </a>
                </div>
              </div>

              <h3 className="font-cormorant text-2xl mb-4 flex items-center">
                <Car className="text-primary mr-3 h-5 w-5" />
                Come Arrivare
              </h3>

              <div className="space-y-4 mb-6">
                <div>
                  <h4 className="font-medium mb-1">In Auto</h4>
                  <p className="text-gray-700">
                    Dall'autostrada A1, prendere l'uscita Capua e seguire le
                    indicazioni per Roccaromana. La tenuta si trova sulla Via Castello 
                    in direzione centro storico.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium mb-1">In Treno</h4>
                  <p className="text-gray-700">
                    La stazione più vicina è Napoli Centrale. Da lì è
                    possibile prendere un taxi (circa 50 minuti) o noleggiare un'auto.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium mb-1">In Aereo</h4>
                  <p className="text-gray-700">
                    L'aeroporto di Napoli-Capodichino è a circa 60 minuti di auto dalla
                    tenuta. Dall'aeroporto è possibile noleggiare un'auto o prendere
                    un taxi.
                  </p>
                </div>
              </div>
            </Card>
          </ScrollAnimator>

          <ScrollAnimator>
            <Card className="bg-white p-8 rounded-lg shadow-lg">
              <h3 className="font-cormorant text-2xl mb-6 flex items-center">
                <Bed className="text-primary mr-3 h-5 w-5" />
                Alloggi Consigliati
              </h3>

              <div className="space-y-6">
                <div className="pb-4 border-b border-gray-200">
                  <h4 className="font-medium text-lg mb-1">Tenuta Donna Fausta</h4>
                  <p className="text-gray-700 mb-2">
                    La tenuta dispone di 12 camere per gli ospiti, che abbiamo
                    riservato per i parenti più stretti.
                  </p>
                  <div className="flex items-center text-primary mb-2">
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                  </div>
                  <p className="text-gray-700 italic">Distanza dalla sede: in loco</p>
                </div>

                <div className="pb-4 border-b border-gray-200">
                  <h4 className="font-medium text-lg mb-1">Hotel Castello</h4>
                  <p className="text-gray-700 mb-2">
                    Un elegante hotel a 4 stelle con vista sulle colline casertane.
                    Menzione il nostro matrimonio per ottenere uno sconto del 10%.
                  </p>
                  <div className="flex items-center text-primary mb-2">
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 text-gray-300" />
                  </div>
                  <p className="text-gray-700 italic">Distanza dalla sede: 2 km</p>
                  <a
                    href="#"
                    className="text-primary hover:text-[#c9a57c] transition-colors"
                  >
                    Prenota ora
                  </a>
                </div>

                <div className="pb-4 border-b border-gray-200">
                  <h4 className="font-medium text-lg mb-1">Agriturismo Il Casale</h4>
                  <p className="text-gray-700 mb-2">
                    Un autentico agriturismo campano immerso tra vigneti e uliveti,
                    con colazione a base di prodotti locali.
                  </p>
                  <div className="flex items-center text-primary mb-2">
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 fill-current" />
                    <Star className="h-4 w-4 text-gray-300" />
                  </div>
                  <p className="text-gray-700 italic">Distanza dalla sede: 5 km</p>
                  <a
                    href="#"
                    className="text-primary hover:text-[#c9a57c] transition-colors"
                  >
                    Prenota ora
                  </a>
                </div>

                <p className="text-gray-700">
                  Per qualsiasi assistenza con la prenotazione degli alloggi, non
                  esitate a contattarci.
                </p>
              </div>
            </Card>
          </ScrollAnimator>
        </div>
      </div>
    </section>
  );
}
