import { useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import ScrollAnimator from "./ScrollAnimator";
import { motion, AnimatePresence } from "framer-motion";

interface GalleryImage {
  src: string;
  alt: string;
}

export default function Gallery() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Gallery images
  const galleryImages: GalleryImage[] = [
    {
      src: "https://images.unsplash.com/photo-1522673607200-164d1b3ce551?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600&q=80",
      alt: "Coppia che ride",
    },
    {
      src: "https://images.unsplash.com/photo-1529634806980-85c3dd6d34ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600&q=80",
      alt: "Coppia sulla spiaggia",
    },
    {
      src: "https://images.unsplash.com/photo-1537907510278-a722ee0ae9ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600&q=80",
      alt: "Momenti romantici",
    },
    {
      src: "https://images.unsplash.com/photo-1508214832820-ae701f6132a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600&q=80",
      alt: "Viaggio insieme",
    },
    {
      src: "https://images.unsplash.com/photo-1490650404511-5cc01ac58dd8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600&q=80",
      alt: "Momento speciale",
    },
    {
      src: "https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600&q=80",
      alt: "Insieme in città",
    },
    {
      src: "https://images.unsplash.com/photo-1529417305485-480f579e7578?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600&q=80",
      alt: "Primo viaggio",
    },
    {
      src: "https://images.unsplash.com/photo-1523622805393-a76e08d71e79?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600&q=80",
      alt: "Momenti di risate",
    },
  ];

  const openModal = (index: number) => {
    setCurrentImageIndex(index);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % galleryImages.length);
  };

  const prevImage = () => {
    setCurrentImageIndex(
      (prev) => (prev - 1 + galleryImages.length) % galleryImages.length
    );
  };

  return (
    <section id="gallery" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <ScrollAnimator>
          <div className="text-center mb-16">
            <h2 className="font-cormorant text-4xl md:text-5xl mb-4">
              La Nostra Galleria
            </h2>
            <div className="w-20 h-0.5 bg-primary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-gray-700">
              I momenti più belli della nostra storia insieme.
            </p>
          </div>
        </ScrollAnimator>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <ScrollAnimator key={index}>
              <div
                className="overflow-hidden rounded-lg shadow-md cursor-pointer transition-transform duration-300 hover:scale-[1.02]"
                onClick={() => openModal(index)}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
            </ScrollAnimator>
          ))}
        </div>
      </div>

      {/* Image Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-screen-lg p-0 bg-transparent border-none">
          <div className="relative flex items-center justify-center bg-black bg-opacity-90 w-full h-full rounded-lg">
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 text-white hover:text-primary transition-colors z-50"
              aria-label="Close modal"
            >
              <X className="h-8 w-8" />
            </button>

            <button
              onClick={prevImage}
              className="absolute left-4 text-white hover:text-primary transition-colors z-40"
              aria-label="Previous image"
            >
              <ChevronLeft className="h-10 w-10" />
            </button>

            <AnimatePresence mode="wait">
              <motion.img
                key={currentImageIndex}
                src={galleryImages[currentImageIndex].src}
                alt={galleryImages[currentImageIndex].alt}
                className="max-w-[90%] max-h-[80vh] object-contain"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              />
            </AnimatePresence>

            <button
              onClick={nextImage}
              className="absolute right-4 text-white hover:text-primary transition-colors z-40"
              aria-label="Next image"
            >
              <ChevronRight className="h-10 w-10" />
            </button>

            <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2">
              {galleryImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentImageIndex ? "bg-primary" : "bg-gray-400"
                  }`}
                  aria-label={`Go to image ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}
