import { Card } from "@/components/ui/card";
import { Church, GlassWater, Music, MapPin } from "lucide-react";
import ScrollAnimator from "./ScrollAnimator";

export default function EventDetails() {
  const timelineItems = [
    {
      time: "14:30",
      title: "Arrivo degli Ospiti",
      description:
        "Gli ospiti sono invitati ad arrivare alla tenuta 30 minuti prima dell'inizio della cerimonia.",
    },
    {
      time: "15:00",
      title: "Cerimonia",
      description: "Celebrazione del matrimonio nella Tenuta Donna Fausta.",
    },
    {
      time: "16:30",
      title: "Foto di Gruppo",
      description: "Foto ricordo con tutti gli invitati nei giardini della tenuta.",
    },
    {
      time: "17:30",
      title: "Aperitivo di Benvenuto",
      description: "Cocktail e antipasti nei giardini della Tenuta Donna Fausta.",
    },
    {
      time: "19:00",
      title: "Cena",
      description: "Cena elegante servita nella sala principale della tenuta.",
    },
    {
      time: "21:00",
      title: "Taglio della Torta",
      description: "Momento speciale seguito dall'inizio delle danze.",
    },
  ];

  return (
    <section id="eventi" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <ScrollAnimator>
          <div className="text-center mb-16">
            <h2 className="font-cormorant text-4xl md:text-5xl mb-4">
              Dettagli Evento
            </h2>
            <div className="w-20 h-0.5 bg-primary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-gray-700">
              Siamo entusiasti di celebrare il nostro amore con amici e familiari.
              Ecco tutti i dettagli per il nostro grande giorno.
            </p>
          </div>
        </ScrollAnimator>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <ScrollAnimator>
            <Card className="bg-white p-8 shadow-lg rounded-lg text-center">
              <div className="w-16 h-16 rounded-full gold-gradient flex items-center justify-center mx-auto mb-4">
                <Church className="text-white text-xl" />
              </div>
              <h3 className="font-cormorant text-2xl mb-3">Cerimonia</h3>
              <p className="text-gray-700 mb-2">21 Dicembre 2025, 15:00</p>
              <p className="text-gray-700 mb-4">
                Tenuta Donna Fausta
                <br />
                Via Castello, 81051 Roccaromana CE
              </p>
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-[#c9a57c] transition-colors inline-flex items-center"
              >
                <span>Visualizza mappa</span>
                <MapPin className="ml-2 h-4 w-4" />
              </a>
            </Card>
          </ScrollAnimator>

          <ScrollAnimator>
            <Card className="bg-white p-8 shadow-lg rounded-lg text-center">
              <div className="w-16 h-16 rounded-full gold-gradient flex items-center justify-center mx-auto mb-4">
                <GlassWater className="text-white text-xl" />
              </div>
              <h3 className="font-cormorant text-2xl mb-3">Ricevimento</h3>
              <p className="text-gray-700 mb-2">21 Dicembre 2025, 17:30</p>
              <p className="text-gray-700 mb-4">
                Tenuta Donna Fausta
                <br />
                Via Castello, 81051 Roccaromana CE
              </p>
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-[#c9a57c] transition-colors inline-flex items-center"
              >
                <span>Visualizza mappa</span>
                <MapPin className="ml-2 h-4 w-4" />
              </a>
            </Card>
          </ScrollAnimator>

          <ScrollAnimator>
            <Card className="bg-white p-8 shadow-lg rounded-lg text-center">
              <div className="w-16 h-16 rounded-full gold-gradient flex items-center justify-center mx-auto mb-4">
                <Music className="text-white text-xl" />
              </div>
              <h3 className="font-cormorant text-2xl mb-3">Festa</h3>
              <p className="text-gray-700 mb-2">21 Dicembre 2025, 21:00</p>
              <p className="text-gray-700 mb-4">
                Tenuta Donna Fausta
                <br />
                Giardino e Terrazza
              </p>
              <p className="text-gray-600 italic">
                Musica e balli fino a tarda notte
              </p>
            </Card>
          </ScrollAnimator>
        </div>

        <div className="max-w-3xl mx-auto mt-20">
          <ScrollAnimator>
            <h3 className="font-cormorant text-2xl text-center mb-10">
              Programma della Giornata
            </h3>
          </ScrollAnimator>

          <div className="pl-10 md:pl-0 md:ml-10 relative">
            <div className="hidden md:block absolute left-0 top-0 bottom-0 w-0.5 bg-[#c9a57c] opacity-30"></div>

            <div className="space-y-12">
              {timelineItems.map((item, index) => (
                <ScrollAnimator key={index}>
                  <div className="timeline-item relative">
                    <div className="timeline-dot md:block hidden"></div>
                    <div className="bg-white p-6 rounded-lg shadow-sm md:ml-6">
                      <h4 className="font-cormorant text-xl mb-1">
                        {item.time} - {item.title}
                      </h4>
                      <p className="text-gray-700">{item.description}</p>
                    </div>
                  </div>
                </ScrollAnimator>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
