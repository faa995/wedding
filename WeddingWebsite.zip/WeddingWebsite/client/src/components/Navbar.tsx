import { useState, useEffect } from "react";
import { cn, colors } from "@/lib/utils";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleNavClick = () => {
    setIsMenuOpen(false);
  };

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "La Nostra Storia", href: "#storia" },
    { name: "Eventi", href: "#eventi" },
    { name: "Galleria", href: "#gallery" },
    { name: "Viaggio", href: "#viaggio" },
    { name: "Regali", href: "#regali" },
    { name: "RSVP", href: "#rsvp" },
  ];

  return (
    <header className={cn(
      "fixed w-full bg-white bg-opacity-95 shadow-sm z-40 transition-all duration-300",
      isScrolled ? "py-2" : "py-3"
    )}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        <a 
          href="#home" 
          className="font-great-vibes text-[#c9a57c] text-3xl hover:text-[#d4b78f] transition-colors"
        >
          S & M
        </a>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a 
                  href={link.href} 
                  className="text-sm uppercase tracking-wide hover:text-[#d4b78f] transition-colors"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMenu}
          className="md:hidden text-[#333333] focus:outline-none"
          aria-label="Toggle menu"
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor" 
            className="w-6 h-6"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M4 6h16M4 12h16M4 18h16" 
            />
          </svg>
        </button>
      </div>
      
      {/* Mobile Navigation */}
      <div 
        className={cn(
          "md:hidden bg-white absolute w-full left-0 shadow-md transition-all duration-300 transform",
          isMenuOpen 
            ? "opacity-100 max-h-96" 
            : "opacity-0 max-h-0 overflow-hidden"
        )}
      >
        <div className="container mx-auto px-4 py-3">
          <ul className="space-y-4 pb-4">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a 
                  href={link.href} 
                  className="block text-sm uppercase tracking-wide hover:text-[#d4b78f] py-2 transition-colors"
                  onClick={handleNavClick}
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </header>
  );
}
