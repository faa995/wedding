import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import CountdownTimer from "./CountdownTimer";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center bg-cover bg-center relative"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&auto=format&fit=crop&w=1350&q=80')",
      }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-40"></div>
      <motion.div 
        className="container mx-auto px-4 text-center relative z-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <h1 className="font-great-vibes text-5xl md:text-7xl lg:text-8xl text-white mb-4">
          Fabio & Denise
        </h1>
        <p className="font-cormorant text-xl md:text-2xl text-white uppercase tracking-widest mb-6">
          CI SPOSIAMO
        </p>
        <div className="w-24 h-0.5 bg-white mx-auto mb-6"></div>
        <p className="font-montserrat text-xl text-white mb-10">
          21 Dicembre 2025 • Tenuta Donna Fausta, Roccaromana
        </p>

        <div className="flex flex-col md:flex-row justify-center space-y-4 md:space-y-0 md:space-x-6 mb-10">
          <Button
            size="lg"
            className="bg-primary hover:bg-primary/80 text-white border-2 border-primary hover:border-white hover:bg-transparent"
            asChild
          >
            <a href="#rsvp">Conferma Presenza</a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-2 border-white text-white hover:bg-white hover:text-foreground"
            asChild
          >
            <a href="#eventi">Dettagli Evento</a>
          </Button>
        </div>

        <CountdownTimer targetDate="2025-12-21T15:00:00" />
      </motion.div>

      <a
        href="#storia"
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white animate-bounce"
      >
        <ChevronDown className="h-6 w-6" />
      </a>
    </section>
  );
}
