import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header
      className={`fixed w-full bg-white bg-opacity-95 shadow-sm z-40 transition-all duration-300 ${
        scrolled ? "py-2" : "py-3"
      }`}
      id="navbar"
    >
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <a
          href="#home"
          className="font-great-vibes text-[#c9a57c] text-3xl hover:text-primary transition-colors"
        >
          S & M
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            <li>
              <a
                href="#home"
                className="text-sm uppercase tracking-wide hover:text-primary transition-colors"
              >
                Home
              </a>
            </li>
            <li>
              <a
                href="#storia"
                className="text-sm uppercase tracking-wide hover:text-primary transition-colors"
              >
                La Nostra Storia
              </a>
            </li>
            <li>
              <a
                href="#eventi"
                className="text-sm uppercase tracking-wide hover:text-primary transition-colors"
              >
                Eventi
              </a>
            </li>
            <li>
              <a
                href="#gallery"
                className="text-sm uppercase tracking-wide hover:text-primary transition-colors"
              >
                Galleria
              </a>
            </li>
            <li>
              <a
                href="#viaggio"
                className="text-sm uppercase tracking-wide hover:text-primary transition-colors"
              >
                Viaggio
              </a>
            </li>
            <li>
              <a
                href="#regali"
                className="text-sm uppercase tracking-wide hover:text-primary transition-colors"
              >
                Regali
              </a>
            </li>
            <li>
              <a
                href="#rsvp"
                className="text-sm uppercase tracking-wide hover:text-primary transition-colors"
              >
                RSVP
              </a>
            </li>
          </ul>
        </nav>

        {/* Mobile Menu Button */}
        <button
          onClick={toggleMenu}
          className="md:hidden text-foreground focus:outline-none"
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Navigation */}
      <div
        className={`${
          isMenuOpen ? "block" : "hidden"
        } md:hidden bg-white absolute w-full left-0 shadow-md animate-in fade-in duration-300`}
      >
        <div className="container mx-auto px-4 py-3">
          <ul className="space-y-4 pb-4">
            <li>
              <a
                href="#home"
                onClick={closeMenu}
                className="block text-sm uppercase tracking-wide hover:text-primary py-2 transition-colors"
              >
                Home
              </a>
            </li>
            <li>
              <a
                href="#storia"
                onClick={closeMenu}
                className="block text-sm uppercase tracking-wide hover:text-primary py-2 transition-colors"
              >
                La Nostra Storia
              </a>
            </li>
            <li>
              <a
                href="#eventi"
                onClick={closeMenu}
                className="block text-sm uppercase tracking-wide hover:text-primary py-2 transition-colors"
              >
                Eventi
              </a>
            </li>
            <li>
              <a
                href="#gallery"
                onClick={closeMenu}
                className="block text-sm uppercase tracking-wide hover:text-primary py-2 transition-colors"
              >
                Galleria
              </a>
            </li>
            <li>
              <a
                href="#viaggio"
                onClick={closeMenu}
                className="block text-sm uppercase tracking-wide hover:text-primary py-2 transition-colors"
              >
                Viaggio
              </a>
            </li>
            <li>
              <a
                href="#regali"
                onClick={closeMenu}
                className="block text-sm uppercase tracking-wide hover:text-primary py-2 transition-colors"
              >
                Regali
              </a>
            </li>
            <li>
              <a
                href="#rsvp"
                onClick={closeMenu}
                className="block text-sm uppercase tracking-wide hover:text-primary py-2 transition-colors"
              >
                RSVP
              </a>
            </li>
          </ul>
        </div>
      </div>
    </header>
  );
}
