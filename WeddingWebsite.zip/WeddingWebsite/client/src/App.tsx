import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthContext, useProvideAuth } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Login from "@/pages/Login";
import React, { Suspense, lazy } from "react";
import { Loader2 } from "lucide-react";

// Lazy load admin pages
const AdminDashboard = lazy(() => import("@/pages/admin/Dashboard"));
const AdminRsvp = lazy(() => import("@/pages/admin/Rsvp"));
const AdminEvents = lazy(() => import("@/pages/admin/Events"));
const AdminGallery = lazy(() => import("@/pages/admin/Gallery"));
const AdminSettings = lazy(() => import("@/pages/admin/Settings"));
const AdminGuests = lazy(() => import("@/pages/admin/Guests"));

// Componente per proteggere le rotte admin
function ProtectedRoute({ component: Component, ...rest }: any) {
  const { isAuthenticated, isLoading } = useAuth();
  const [, navigate] = useLocation();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!isAuthenticated) {
    navigate("/login");
    return null;
  }
  
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    }>
      <Component {...rest} />
    </Suspense>
  );
}

// Hook custom per utilizzare il contesto di autenticazione
function useAuth() {
  return React.useContext(AuthContext);
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      
      {/* Rotte admin protette */}
      <Route path="/admin">
        {(params) => <ProtectedRoute component={AdminDashboard} params={params} />}
      </Route>
      <Route path="/admin/rsvp">
        {(params) => <ProtectedRoute component={AdminRsvp} params={params} />}
      </Route>
      <Route path="/admin/events">
        {(params) => <ProtectedRoute component={AdminEvents} params={params} />}
      </Route>
      <Route path="/admin/gallery">
        {(params) => <ProtectedRoute component={AdminGallery} params={params} />}
      </Route>
      <Route path="/admin/settings">
        {(params) => <ProtectedRoute component={AdminSettings} params={params} />}
      </Route>
      <Route path="/admin/guests">
        {(params) => <ProtectedRoute component={AdminGuests} params={params} />}
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const auth = useProvideAuth();
  
  return (
    <QueryClientProvider client={queryClient}>
      <AuthContext.Provider value={auth}>
        <Router />
        <Toaster />
      </AuthContext.Provider>
    </QueryClientProvider>
  );
}

export default App;
