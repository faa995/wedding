import { useState, useEffect } from 'react';

type CountdownReturn = {
  days: string;
  hours: string;
  minutes: string;
  seconds: string;
  isComplete: boolean;
};

export default function useCountdown(targetDate: Date): CountdownReturn {
  const [countdown, setCountdown] = useState<CountdownReturn>({
    days: '00',
    hours: '00',
    minutes: '00',
    seconds: '00',
    isComplete: false
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetDate.getTime() - now;
      
      if (distance <= 0) {
        setCountdown({
          days: '00',
          hours: '00',
          minutes: '00',
          seconds: '00',
          isComplete: true
        });
        clearInterval(interval);
        return;
      }
      
      // Calculate time units
      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);
      
      // Format time units to always show two digits
      setCountdown({
        days: days.toString().padStart(2, '0'),
        hours: hours.toString().padStart(2, '0'),
        minutes: minutes.toString().padStart(2, '0'),
        seconds: seconds.toString().padStart(2, '0'),
        isComplete: false
      });
    }, 1000);
    
    return () => clearInterval(interval);
  }, [targetDate]);

  return countdown;
}
