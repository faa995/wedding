import { useEffect, useRef, useState } from 'react';

interface UseIntersectionObserverProps {
  threshold?: number;
  rootMargin?: string;
}

export default function useIntersectionObserver({
  threshold = 0.2,
  rootMargin = '0px',
}: UseIntersectionObserverProps = {}) {
  const [elements, setElements] = useState<Map<Element, boolean>>(new Map());
  const observer = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observer.current = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          setElements(prev => {
            const newMap = new Map(prev);
            newMap.set(entry.target, entry.isIntersecting);
            return newMap;
          });
        });
      },
      {
        threshold,
        rootMargin,
      }
    );

    return () => {
      if (observer.current) {
        observer.current.disconnect();
      }
    };
  }, [threshold, rootMargin]);

  const observe = (element: Element | null) => {
    if (!element || !observer.current) return;
    
    observer.current.observe(element);
    setElements(prev => {
      const newMap = new Map(prev);
      newMap.set(element, false);
      return newMap;
    });

    return () => {
      if (observer.current) {
        observer.current.unobserve(element);
        setElements(prev => {
          const newMap = new Map(prev);
          newMap.delete(element);
          return newMap;
        });
      }
    };
  };

  return { observe, isIntersecting: (element: Element | null) => element ? elements.get(element) : false };
}
