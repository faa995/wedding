import React, { ReactNode, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { 
  LayoutDashboard, 
  Mail, 
  Calendar, 
  Image, 
  Settings, 
  Users, 
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

interface AdminLayoutProps {
  children: ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const { logout, user } = useAuth();
  const [location] = useLocation();
  const [isSheetOpen, setIsSheetOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
  };

  const navItems = [
    {
      title: 'Dashboard',
      href: '/admin',
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: 'RSVP',
      href: '/admin/rsvp',
      icon: <Mail className="h-5 w-5" />,
    },
    {
      title: 'Eventi',
      href: '/admin/events',
      icon: <Calendar className="h-5 w-5" />,
    },
    {
      title: 'Invitati',
      href: '/admin/guests',
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: 'Galleria',
      href: '/admin/gallery',
      icon: <Image className="h-5 w-5" />,
    },
    {
      title: 'Impostazioni',
      href: '/admin/settings',
      icon: <Settings className="h-5 w-5" />,
    },
  ];

  // Componente per il menu di navigazione condiviso tra desktop e mobile
  const NavItems = () => (
    <div className="space-y-1">
      {navItems.map((item) => (
        <Link key={item.href} href={item.href}>
          <Button
            variant={location === item.href ? "secondary" : "ghost"}
            className="w-full justify-start"
            onClick={() => setIsSheetOpen(false)}
          >
            {item.icon}
            <span className="ml-2">{item.title}</span>
          </Button>
        </Link>
      ))}
    </div>
  );

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar per desktop */}
      <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-grow pt-5 border-r border-border bg-card overflow-y-auto">
          <div className="flex items-center px-4">
            <h1 className="text-xl font-bold">Admin Panel</h1>
          </div>
          <div className="flex flex-col px-3 mt-6 flex-grow">
            <NavItems />
          </div>
          <div className="p-4 border-t border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Avatar>
                  <AvatarFallback>
                    {user?.username?.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">{user?.username}</p>
                  <p className="text-xs text-muted-foreground">Amministratore</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                title="Logout"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </aside>

      {/* Header mobile con hamburger menu */}
      <header className="md:hidden sticky top-0 z-10 bg-background border-b border-border">
        <div className="px-4 py-3 flex justify-between items-center">
          <h1 className="text-xl font-bold">Admin Panel</h1>
          <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0">
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-4 border-b">
                  <h2 className="text-lg font-semibold">Menu</h2>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsSheetOpen(false)}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
                <div className="flex-grow p-4 overflow-y-auto">
                  <NavItems />
                </div>
                <div className="p-4 border-t">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarFallback>
                          {user?.username?.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{user?.username}</p>
                        <p className="text-xs text-muted-foreground">Amministratore</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleLogout}
                      title="Logout"
                    >
                      <LogOut className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main content area */}
      <main className="flex-1 md:ml-64 p-6 pt-24 md:pt-6 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}