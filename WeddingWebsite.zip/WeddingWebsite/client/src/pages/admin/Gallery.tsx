import React, { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import AdminLayout from './components/AdminLayout';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  ArrowDown,
  ArrowUp,
  Edit,
  ImageIcon,
  Loader2,
  Plus,
  Trash2,
} from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

const galleryItemSchema = z.object({
  title: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
  imageUrl: z.string().url("L'URL dell'immagine non è valido"),
  order: z.number().default(0),
});

const newGalleryItemSchema = z.object({
  title: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
  imageFile: z
    .any()
    .refine((files) => files?.length === 1, "L'immagine è obbligatoria")
    .refine(
      (files) => files?.[0]?.size <= MAX_FILE_SIZE,
      "L'immagine deve essere più piccola di 5MB"
    )
    .refine(
      (files) => ACCEPTED_IMAGE_TYPES.includes(files?.[0]?.type),
      "Formato accettato: .jpg, .jpeg, .png, .webp"
    ),
  order: z.number().default(0),
});

type GalleryItemFormValues = z.infer<typeof galleryItemSchema>;
type NewGalleryItemFormValues = z.infer<typeof newGalleryItemSchema>;

export default function GalleryPage() {
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<number | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: galleryItems, isLoading } = useQuery({
    queryKey: ['/api/gallery'],
  });

  const form = useForm<GalleryItemFormValues | NewGalleryItemFormValues>({
    resolver: zodResolver(editingItem ? galleryItemSchema : newGalleryItemSchema),
    defaultValues: editingItem
      ? {
          title: editingItem.title || '',
          description: editingItem.description || '',
          imageUrl: editingItem.imageUrl,
          order: editingItem.order || 0,
        }
      : {
          title: '',
          description: '',
          order: galleryItems?.length || 0,
        },
  });

  React.useEffect(() => {
    if (editingItem) {
      form.reset({
        title: editingItem.title || '',
        description: editingItem.description || '',
        imageUrl: editingItem.imageUrl,
        order: editingItem.order || 0,
      });
      setPreviewUrl(editingItem.imageUrl);
    } else {
      form.reset({
        title: '',
        description: '',
        order: galleryItems?.length || 0,
      });
      setPreviewUrl(null);
    }
  }, [editingItem, form, galleryItems?.length]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const createGalleryItemMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      setUploadingImage(true);
      try {
        const response = await apiRequest('/api/gallery', {
          method: 'POST',
          body: formData,
        });
        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.message || 'Errore durante il caricamento dell\'immagine');
        }
        return response.json();
      } finally {
        setUploadingImage(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/gallery'] });
      toast({
        title: 'Immagine caricata',
        description: 'L\'immagine è stata caricata con successo.',
      });
      setItemDialogOpen(false);
      setPreviewUrl(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante il caricamento dell\'immagine',
        variant: 'destructive',
      });
    },
  });

  const updateGalleryItemMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: GalleryItemFormValues }) => {
      const response = await apiRequest(`/api/gallery/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'aggiornamento dell\'immagine');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/gallery'] });
      toast({
        title: 'Immagine aggiornata',
        description: 'L\'immagine è stata aggiornata con successo.',
      });
      setItemDialogOpen(false);
      setEditingItem(null);
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante l\'aggiornamento dell\'immagine',
        variant: 'destructive',
      });
    },
  });

  const deleteGalleryItemMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest(`/api/gallery/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'eliminazione dell\'immagine');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/gallery'] });
      toast({
        title: 'Immagine eliminata',
        description: 'L\'immagine è stata eliminata con successo.',
      });
      setDeleteDialogOpen(false);
      setItemToDelete(null);
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante l\'eliminazione dell\'immagine',
        variant: 'destructive',
      });
    },
  });

  const reorderGalleryItemMutation = useMutation({
    mutationFn: async ({ id, newOrder }: { id: number; newOrder: number }) => {
      const response = await apiRequest(`/api/gallery/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ order: newOrder }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante il riordinamento dell\'immagine');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/gallery'] });
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante il riordinamento dell\'immagine',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (values: GalleryItemFormValues | NewGalleryItemFormValues) => {
    if (editingItem) {
      updateGalleryItemMutation.mutate({
        id: editingItem.id,
        data: values as GalleryItemFormValues,
      });
    } else {
      const formData = new FormData();
      const values = form.getValues() as NewGalleryItemFormValues;
      
      if (values.title) formData.append('title', values.title);
      if (values.description) formData.append('description', values.description);
      formData.append('order', values.order.toString());
      formData.append('image', values.imageFile[0]);
      
      createGalleryItemMutation.mutate(formData);
    }
  };

  const handleMoveUp = (item: any, index: number) => {
    if (index === 0) return;
    const prevItem = galleryItems[index - 1];
    
    // Swap order values
    reorderGalleryItemMutation.mutate({ id: item.id, newOrder: prevItem.order });
    reorderGalleryItemMutation.mutate({ id: prevItem.id, newOrder: item.order });
  };

  const handleMoveDown = (item: any, index: number) => {
    if (!galleryItems || index === galleryItems.length - 1) return;
    const nextItem = galleryItems[index + 1];
    
    // Swap order values
    reorderGalleryItemMutation.mutate({ id: item.id, newOrder: nextItem.order });
    reorderGalleryItemMutation.mutate({ id: nextItem.id, newOrder: item.order });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-3xl font-bold">Galleria</h1>
          <div className="mt-2 sm:mt-0">
            <Dialog open={itemDialogOpen} onOpenChange={setItemDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Aggiungi Immagine
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[550px]">
                <DialogHeader>
                  <DialogTitle>
                    {editingItem ? 'Modifica immagine' : 'Aggiungi nuova immagine'}
                  </DialogTitle>
                  <DialogDescription>
                    {editingItem
                      ? 'Modifica i dettagli dell\'immagine'
                      : 'Carica una nuova immagine alla galleria'}
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    {!editingItem && (
                      <FormField
                        control={form.control}
                        name="imageFile"
                        render={({ field: { onChange, value, ...field } }) => (
                          <FormItem>
                            <FormLabel>Immagine*</FormLabel>
                            <FormControl>
                              <Input
                                type="file"
                                accept=".jpg,.jpeg,.png,.webp"
                                onChange={(e) => {
                                  handleFileChange(e);
                                  onChange(e.target.files);
                                }}
                                ref={fileInputRef}
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Formati supportati: JPG, PNG, WEBP (max 5MB)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                    
                    {editingItem && (
                      <FormField
                        control={form.control}
                        name="imageUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>URL Immagine</FormLabel>
                            <FormControl>
                              <Input disabled {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    {previewUrl && (
                      <div className="mt-2 border rounded-md overflow-hidden">
                        <img
                          src={previewUrl}
                          alt="Preview"
                          className="w-full h-auto max-h-[200px] object-contain"
                        />
                      </div>
                    )}

                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Titolo</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Titolo dell'immagine" 
                              {...field} 
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Descrizione</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Descrizione dell'immagine" 
                              className="resize-none" 
                              {...field} 
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="order"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ordine</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormDescription>
                            Le immagini vengono mostrate in ordine crescente
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={
                          createGalleryItemMutation.isPending || 
                          updateGalleryItemMutation.isPending || 
                          uploadingImage
                        }
                      >
                        {(createGalleryItemMutation.isPending || 
                          updateGalleryItemMutation.isPending || 
                          uploadingImage) && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        {editingItem ? 'Aggiorna' : 'Carica'}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Galleria di foto</CardTitle>
            <CardDescription>
              Gestisci le immagini mostrate nella galleria del matrimonio
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : !galleryItems || galleryItems.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <ImageIcon className="mx-auto h-12 w-12 opacity-20 mb-2" />
                <p>Nessuna immagine trovata</p>
                <p className="text-sm">Clicca su "Aggiungi Immagine" per iniziare</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {galleryItems.map((item: any, index: number) => (
                  <Card key={item.id} className="overflow-hidden">
                    <div className="relative pt-[75%]">
                      <img
                        src={item.imageUrl}
                        alt={item.title || 'Immagine galleria'}
                        className="absolute top-0 left-0 w-full h-full object-cover"
                      />
                    </div>
                    <CardContent className="p-3">
                      <div className="flex justify-between items-start">
                        <div className="overflow-hidden">
                          {item.title && (
                            <p className="font-medium text-sm truncate">{item.title}</p>
                          )}
                          {item.description && (
                            <p className="text-xs text-muted-foreground truncate">
                              {item.description}
                            </p>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            disabled={index === 0 || reorderGalleryItemMutation.isPending}
                            onClick={() => handleMoveUp(item, index)}
                          >
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            disabled={
                              index === galleryItems.length - 1 || 
                              reorderGalleryItemMutation.isPending
                            }
                            onClick={() => handleMoveDown(item, index)}
                          >
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex justify-end mt-2 gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => {
                            setEditingItem(item);
                            setItemDialogOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => {
                            setItemToDelete(item.id);
                            setDeleteDialogOpen(true);
                          }}
                          disabled={deleteGalleryItemMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
          {galleryItems && galleryItems.length > 0 && (
            <CardFooter>
              <div className="text-xs text-muted-foreground">
                Totale: {galleryItems.length} immagini
              </div>
            </CardFooter>
          )}
        </Card>
      </div>

      {/* Dialog di conferma eliminazione */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sei sicuro?</AlertDialogTitle>
            <AlertDialogDescription>
              Questa azione non può essere annullata. Questo eliminerà permanentemente l'immagine.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (itemToDelete) {
                  deleteGalleryItemMutation.mutate(itemToDelete);
                }
              }}
              disabled={deleteGalleryItemMutation.isPending}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteGalleryItemMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}