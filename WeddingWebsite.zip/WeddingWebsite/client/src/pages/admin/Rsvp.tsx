import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronDown, Download, Loader2, RefreshCw, Search } from 'lucide-react';
import AdminLayout from './components/AdminLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { formatDate } from '@/lib/utils';

export default function RsvpPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [attendingFilter, setAttendingFilter] = useState<string | null>(null);

  const { data: rsvps, isLoading, refetch } = useQuery({
    queryKey: ['/api/admin/rsvps'],
  });

  const filteredRsvps = rsvps
    ? rsvps.filter((rsvp: any) => {
        const matchesSearch =
          !searchQuery ||
          rsvp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          rsvp.email.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesAttending = 
          !attendingFilter || 
          (attendingFilter === 'attending' && rsvp.attending.includes('yes')) ||
          (attendingFilter === 'notAttending' && !rsvp.attending.includes('yes'));

        return matchesSearch && matchesAttending;
      })
    : [];

  const totalGuests = filteredRsvps.reduce((acc: number, rsvp: any) => {
    // Ogni RSVP conta come 1 persona, più eventuali ospiti aggiuntivi
    return acc + 1 + (rsvp.guestNames ? rsvp.guestNames.length : 0);
  }, 0);

  const exportToCSV = () => {
    if (!rsvps || rsvps.length === 0) return;

    const headers = [
      'Nome', 
      'Email', 
      'Telefono', 
      'Partecipa', 
      'Ospiti', 
      'Esigenze Alimentari', 
      'Messaggio', 
      'Data'
    ];

    const csvContent = [
      headers.join(','),
      ...rsvps.map((rsvp: any) => {
        return [
          `"${rsvp.name}"`,
          `"${rsvp.email}"`,
          `"${rsvp.phone || ''}"`,
          `"${rsvp.attending.includes('yes') ? 'Sì' : 'No'}"`,
          `"${rsvp.guestNames ? rsvp.guestNames.join(', ') : ''}"`,
          `"${rsvp.dietary || ''}"`,
          `"${rsvp.message ? rsvp.message.replace(/"/g, '""') : ''}"`,
          `"${formatDate(new Date(rsvp.createdAt))}"`,
        ].join(',');
      }),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `rsvp_list_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-3xl font-bold">RSVP</h1>
          <div className="flex items-center space-x-2 mt-2 sm:mt-0">
            <Button
              variant="outline"
              size="sm"
              className="text-xs h-8"
              onClick={() => refetch()}
            >
              <RefreshCw className="mr-2 h-3.5 w-3.5" />
              Aggiorna
            </Button>
            <Button 
              variant="secondary" 
              size="sm" 
              className="text-xs h-8"
              onClick={exportToCSV}
              disabled={!rsvps || rsvps.length === 0}
            >
              <Download className="mr-2 h-3.5 w-3.5" />
              Esporta CSV
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                Totale risposte
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  filteredRsvps.length
                )}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                Partecipanti
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  filteredRsvps.filter((r: any) => r.attending.includes('yes')).length
                )}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                Non Partecipanti
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  filteredRsvps.filter((r: any) => !r.attending.includes('yes')).length
                )}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                Totale Ospiti
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  totalGuests
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista RSVP</CardTitle>
            <CardDescription>
              Gestisci le risposte di conferma ricevute
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Cerca per nome o email..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="w-full md:w-auto">
                    {!attendingFilter
                      ? "Tutti gli ospiti"
                      : attendingFilter === "attending"
                      ? "Partecipanti"
                      : "Non partecipanti"}
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setAttendingFilter(null)}>
                    Tutti gli ospiti
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setAttendingFilter('attending')}>
                    Partecipanti
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setAttendingFilter('notAttending')}>
                    Non partecipanti
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {isLoading ? (
              <div className="flex items-center justify-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : filteredRsvps.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                Nessun risultato trovato
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ospiti</TableHead>
                      <TableHead>Data</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRsvps.map((rsvp: any) => (
                      <TableRow key={rsvp.id}>
                        <TableCell className="font-medium">{rsvp.name}</TableCell>
                        <TableCell>{rsvp.email}</TableCell>
                        <TableCell>
                          <Badge variant={rsvp.attending.includes('yes') ? "default" : "secondary"}>
                            {rsvp.attending.includes('yes') ? "Conferma" : "Declina"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {rsvp.guestNames && rsvp.guestNames.length > 0 ? (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  {rsvp.guestNames.length} ospiti
                                  <ChevronDown className="ml-1 h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent>
                                {rsvp.guestNames.map((guest: string, index: number) => (
                                  <DropdownMenuItem key={index}>
                                    {guest}
                                  </DropdownMenuItem>
                                ))}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          ) : (
                            "Nessuno"
                          )}
                        </TableCell>
                        <TableCell>
                          {formatDate(new Date(rsvp.createdAt))}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}