import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { Loader2 } from 'lucide-react';
import AdminLayout from './components/AdminLayout';

export default function Dashboard() {
  const { data: rsvps, isLoading: isLoadingRsvps } = useQuery({
    queryKey: ['/api/admin/rsvps'],
  });

  const { data: guests, isLoading: isLoadingGuests } = useQuery({
    queryKey: ['/api/admin/guests'],
  });

  const { data: events, isLoading: isLoadingEvents } = useQuery({
    queryKey: ['/api/events'],
  });

  const { data: galleryItems, isLoading: isLoadingGallery } = useQuery({
    queryKey: ['/api/gallery'],
  });

  const isLoading = isLoadingRsvps || isLoadingGuests || isLoadingEvents || isLoadingGallery;

  const stats = [
    {
      title: "RSVP",
      value: rsvps?.length || 0,
      description: "Risposte confermate"
    },
    {
      title: "Invitati",
      value: guests?.length || 0,
      description: "Invitati totali"
    },
    {
      title: "Eventi",
      value: events?.length || 0,
      description: "Eventi programmati"
    },
    {
      title: "Foto",
      value: galleryItems?.length || 0,
      description: "Nella galleria"
    }
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {isLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Card key={i} className="flex items-center justify-center p-6">
                <Loader2 className="h-8 w-8 animate-spin opacity-50" />
              </Card>
            ))
          ) : (
            stats.map((stat, i) => (
              <Card key={i}>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">
                    {stat.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <p className="text-xs text-muted-foreground">
                    {stat.description}
                  </p>
                </CardContent>
              </Card>
            ))
          )}
        </div>
        
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>RSVP recenti</CardTitle>
              <CardDescription>
                Ultime conferme ricevute
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingRsvps ? (
                <div className="flex items-center justify-center p-6">
                  <Loader2 className="h-8 w-8 animate-spin opacity-50" />
                </div>
              ) : rsvps && rsvps.length > 0 ? (
                <div className="space-y-4">
                  {rsvps.slice(0, 5).map((rsvp: any) => (
                    <div key={rsvp.id} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{rsvp.name}</p>
                        <p className="text-sm text-muted-foreground">{rsvp.email}</p>
                      </div>
                      <div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          rsvp.attending.includes('yes') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {rsvp.attending.includes('yes') ? 'Conferma' : 'Declina'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground">Nessun RSVP ricevuto</p>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Invitati confermati</CardTitle>
              <CardDescription>
                Invitati che hanno confermato la presenza
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingGuests ? (
                <div className="flex items-center justify-center p-6">
                  <Loader2 className="h-8 w-8 animate-spin opacity-50" />
                </div>
              ) : guests && guests.length > 0 ? (
                <div className="space-y-4">
                  {guests
                    .filter((guest: any) => guest.isConfirmed)
                    .slice(0, 5)
                    .map((guest: any) => (
                      <div key={guest.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{guest.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {guest.category || 'Nessuna categoria'}
                          </p>
                        </div>
                        <div>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Confermato
                          </span>
                        </div>
                      </div>
                    ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground">Nessun invitato confermato</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}