import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import AdminLayout from './components/AdminLayout';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ArrowDown,
  ArrowUp,
  Calendar,
  Clock,
  Edit,
  Loader2,
  MapPin,
  Plus,
  Trash2,
} from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { formatDate, formatTime } from '@/lib/utils';

const eventFormSchema = z.object({
  title: z.string().min(1, "Il titolo è obbligatorio"),
  description: z.string().nullable().optional(),
  location: z.string().nullable().optional(),
  date: z.string().min(1, "La data è obbligatoria"),
  startTime: z.string().min(1, "L'ora di inizio è obbligatoria"),
  endTime: z.string().nullable().optional(),
  order: z.number().default(0),
});

type EventFormValues = z.infer<typeof eventFormSchema>;

export default function EventsPage() {
  const [editingEvent, setEditingEvent] = useState<any>(null);
  const [eventDialogOpen, setEventDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [eventToDelete, setEventToDelete] = useState<number | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: events, isLoading } = useQuery({
    queryKey: ['/api/events'],
  });

  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      title: '',
      description: '',
      location: '',
      date: new Date().toISOString().split('T')[0],
      startTime: '12:00',
      endTime: '',
      order: 0,
    },
  });

  React.useEffect(() => {
    if (editingEvent) {
      const date = new Date(editingEvent.date);
      const formattedDate = date.toISOString().split('T')[0];
      
      form.reset({
        title: editingEvent.title,
        description: editingEvent.description || '',
        location: editingEvent.location || '',
        date: formattedDate,
        startTime: editingEvent.startTime,
        endTime: editingEvent.endTime || '',
        order: editingEvent.order || 0,
      });
    } else {
      form.reset({
        title: '',
        description: '',
        location: '',
        date: new Date().toISOString().split('T')[0],
        startTime: '12:00',
        endTime: '',
        order: events?.length || 0,
      });
    }
  }, [editingEvent, form, events?.length]);

  const createEventMutation = useMutation({
    mutationFn: async (event: EventFormValues) => {
      const response = await apiRequest('/api/events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(event),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante la creazione dell\'evento');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      toast({
        title: 'Evento creato',
        description: 'L\'evento è stato creato con successo.',
      });
      setEventDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante la creazione dell\'evento',
        variant: 'destructive',
      });
    },
  });

  const updateEventMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: EventFormValues }) => {
      const response = await apiRequest(`/api/events/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'aggiornamento dell\'evento');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      toast({
        title: 'Evento aggiornato',
        description: 'L\'evento è stato aggiornato con successo.',
      });
      setEventDialogOpen(false);
      setEditingEvent(null);
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante l\'aggiornamento dell\'evento',
        variant: 'destructive',
      });
    },
  });

  const deleteEventMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest(`/api/events/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'eliminazione dell\'evento');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      toast({
        title: 'Evento eliminato',
        description: 'L\'evento è stato eliminato con successo.',
      });
      setDeleteDialogOpen(false);
      setEventToDelete(null);
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante l\'eliminazione dell\'evento',
        variant: 'destructive',
      });
    },
  });

  const reorderEventMutation = useMutation({
    mutationFn: async ({ id, newOrder }: { id: number; newOrder: number }) => {
      const response = await apiRequest(`/api/events/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ order: newOrder }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante il riordinamento dell\'evento');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante il riordinamento dell\'evento',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (values: EventFormValues) => {
    if (editingEvent) {
      updateEventMutation.mutate({ id: editingEvent.id, data: values });
    } else {
      createEventMutation.mutate(values);
    }
  };

  const handleMoveUp = (event: any, index: number) => {
    if (index === 0) return;
    const prevEvent = events[index - 1];
    
    // Swap order values
    reorderEventMutation.mutate({ id: event.id, newOrder: prevEvent.order });
    reorderEventMutation.mutate({ id: prevEvent.id, newOrder: event.order });
  };

  const handleMoveDown = (event: any, index: number) => {
    if (!events || index === events.length - 1) return;
    const nextEvent = events[index + 1];
    
    // Swap order values
    reorderEventMutation.mutate({ id: event.id, newOrder: nextEvent.order });
    reorderEventMutation.mutate({ id: nextEvent.id, newOrder: event.order });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-3xl font-bold">Eventi</h1>
          <div className="mt-2 sm:mt-0">
            <Dialog open={eventDialogOpen} onOpenChange={setEventDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Aggiungi Evento
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[550px]">
                <DialogHeader>
                  <DialogTitle>{editingEvent ? 'Modifica evento' : 'Aggiungi nuovo evento'}</DialogTitle>
                  <DialogDescription>
                    {editingEvent 
                      ? 'Modifica i dettagli dell\'evento' 
                      : 'Inserisci i dettagli del nuovo evento'}
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Titolo*</FormLabel>
                          <FormControl>
                            <Input placeholder="Cerimonia, Ricevimento, ecc." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Data*</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <FormField
                          control={form.control}
                          name="startTime"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Inizio*</FormLabel>
                              <FormControl>
                                <Input type="time" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="endTime"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Fine</FormLabel>
                              <FormControl>
                                <Input 
                                  type="time" 
                                  {...field} 
                                  value={field.value || ''}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Luogo</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Nome della location" 
                              {...field} 
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Descrizione</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Descrizione dell'evento" 
                              className="resize-none" 
                              {...field} 
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="order"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ordine</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormDescription>
                            Gli eventi vengono mostrati in ordine crescente
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={createEventMutation.isPending || updateEventMutation.isPending}
                      >
                        {(createEventMutation.isPending || updateEventMutation.isPending) && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        {editingEvent ? 'Aggiorna' : 'Salva'}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista Eventi</CardTitle>
            <CardDescription>
              Gestisci gli eventi del matrimonio, come cerimonia e ricevimento
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : !events || events.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <Calendar className="mx-auto h-12 w-12 opacity-20 mb-2" />
                <p>Nessun evento trovato</p>
                <p className="text-sm">Clicca su "Aggiungi Evento" per iniziare</p>
              </div>
            ) : (
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-9"></TableHead>
                      <TableHead>Titolo</TableHead>
                      <TableHead>Data e Orario</TableHead>
                      <TableHead>Luogo</TableHead>
                      <TableHead className="text-right">Azioni</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {events.map((event: any, index: number) => (
                      <TableRow key={event.id}>
                        <TableCell className="px-2">
                          <div className="flex flex-col gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              disabled={index === 0 || reorderEventMutation.isPending}
                              onClick={() => handleMoveUp(event, index)}
                            >
                              <ArrowUp className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              disabled={index === events.length - 1 || reorderEventMutation.isPending}
                              onClick={() => handleMoveDown(event, index)}
                            >
                              <ArrowDown className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">
                          {event.title}
                          {event.description && (
                            <p className="text-sm text-muted-foreground truncate max-w-[200px]">
                              {event.description}
                            </p>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center text-sm">
                            <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
                            {formatDate(new Date(event.date))}
                          </div>
                          <div className="flex items-center text-sm mt-1">
                            <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                            {formatTime(new Date(`2000-01-01T${event.startTime}`))}{' '}
                            {event.endTime && (
                              <>
                                - {formatTime(new Date(`2000-01-01T${event.endTime}`))}
                              </>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {event.location ? (
                            <div className="flex items-center text-sm">
                              <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                              {event.location}
                            </div>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setEditingEvent(event);
                                setEventDialogOpen(true);
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setEventToDelete(event.id);
                                setDeleteDialogOpen(true);
                              }}
                              disabled={deleteEventMutation.isPending}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
          {events && events.length > 0 && (
            <CardFooter>
              <div className="text-xs text-muted-foreground">
                Totale: {events.length} eventi
              </div>
            </CardFooter>
          )}
        </Card>
      </div>

      {/* Dialog di conferma eliminazione */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sei sicuro?</AlertDialogTitle>
            <AlertDialogDescription>
              Questa azione non può essere annullata. Questo eliminerà permanentemente l'evento.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (eventToDelete) {
                  deleteEventMutation.mutate(eventToDelete);
                }
              }}
              disabled={deleteEventMutation.isPending}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteEventMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}