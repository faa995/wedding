import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import AdminLayout from './components/AdminLayout';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Calendar, 
  Heart,
  HeartHandshake,
  Loader2, 
  Settings2, 
  User, 
  Users, 
} from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';

// Schema generali
const weddingDetailsSchema = z.object({
  brideFirstName: z.string().min(1, "Il nome è obbligatorio"),
  brideLastName: z.string().min(1, "Il cognome è obbligatorio"),
  groomFirstName: z.string().min(1, "Il nome è obbligatorio"),
  groomLastName: z.string().min(1, "Il cognome è obbligatorio"),
  date: z.string().min(1, "La data è obbligatoria"),
});

const ourStorySchema = z.object({
  storyText: z.string().min(10, "La storia deve essere di almeno 10 caratteri"),
  meetDate: z.string().optional(),
  proposalDate: z.string().optional(),
});

const rsvpSettingsSchema = z.object({
  rsvpEmail: z.string().email("Email non valida").min(1, "L'email è obbligatoria"),
  rsvpDeadlineDate: z.string().min(1, "La data limite è obbligatoria"),
});

const websiteSettingsSchema = z.object({
  siteTitle: z.string().min(1, "Il titolo del sito è obbligatorio"),
  welcomeMessage: z.string().min(1, "Il messaggio di benvenuto è obbligatorio"),
  footerMessage: z.string().optional(),
});

type WeddingDetailsFormValues = z.infer<typeof weddingDetailsSchema>;
type OurStoryFormValues = z.infer<typeof ourStorySchema>;
type RsvpSettingsFormValues = z.infer<typeof rsvpSettingsSchema>;
type WebsiteSettingsFormValues = z.infer<typeof websiteSettingsSchema>;

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("wedding-details");
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: config, isLoading } = useQuery({
    queryKey: ['/api/config'],
  });

  // Inizializza i form con i valori predefiniti
  const weddingDetailsForm = useForm<WeddingDetailsFormValues>({
    resolver: zodResolver(weddingDetailsSchema),
    defaultValues: {
      brideFirstName: '',
      brideLastName: '',
      groomFirstName: '',
      groomLastName: '',
      date: new Date().toISOString().split('T')[0],
    },
  });

  const ourStoryForm = useForm<OurStoryFormValues>({
    resolver: zodResolver(ourStorySchema),
    defaultValues: {
      storyText: '',
      meetDate: '',
      proposalDate: '',
    },
  });

  const rsvpSettingsForm = useForm<RsvpSettingsFormValues>({
    resolver: zodResolver(rsvpSettingsSchema),
    defaultValues: {
      rsvpEmail: '',
      rsvpDeadlineDate: new Date().toISOString().split('T')[0],
    },
  });

  const websiteSettingsForm = useForm<WebsiteSettingsFormValues>({
    resolver: zodResolver(websiteSettingsSchema),
    defaultValues: {
      siteTitle: '',
      welcomeMessage: '',
      footerMessage: '',
    },
  });

  // Aggiorna i valori dei form quando i dati vengono caricati
  React.useEffect(() => {
    if (config) {
      // Wedding Details
      weddingDetailsForm.reset({
        brideFirstName: config.brideFirstName || '',
        brideLastName: config.brideLastName || '',
        groomFirstName: config.groomFirstName || '',
        groomLastName: config.groomLastName || '',
        date: config.weddingDate || new Date().toISOString().split('T')[0],
      });

      // Our Story
      ourStoryForm.reset({
        storyText: config.storyText || '',
        meetDate: config.meetDate || '',
        proposalDate: config.proposalDate || '',
      });

      // RSVP Settings
      rsvpSettingsForm.reset({
        rsvpEmail: config.rsvpEmail || '',
        rsvpDeadlineDate: config.rsvpDeadlineDate || new Date().toISOString().split('T')[0],
      });

      // Website Settings
      websiteSettingsForm.reset({
        siteTitle: config.siteTitle || '',
        welcomeMessage: config.welcomeMessage || '',
        footerMessage: config.footerMessage || '',
      });
    }
  }, [config, weddingDetailsForm, ourStoryForm, rsvpSettingsForm, websiteSettingsForm]);

  const saveConfigMutation = useMutation({
    mutationFn: async (configData: Record<string, string>) => {
      const response = await apiRequest('/api/config', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(configData),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante il salvataggio delle impostazioni');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/config'] });
      toast({
        title: 'Impostazioni salvate',
        description: 'Le impostazioni sono state salvate con successo.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante il salvataggio delle impostazioni',
        variant: 'destructive',
      });
    },
  });

  const onWeddingDetailsSubmit = (values: WeddingDetailsFormValues) => {
    saveConfigMutation.mutate({
      brideFirstName: values.brideFirstName,
      brideLastName: values.brideLastName,
      groomFirstName: values.groomFirstName,
      groomLastName: values.groomLastName,
      weddingDate: values.date,
    });
  };

  const onOurStorySubmit = (values: OurStoryFormValues) => {
    saveConfigMutation.mutate({
      storyText: values.storyText,
      meetDate: values.meetDate || '',
      proposalDate: values.proposalDate || '',
    });
  };

  const onRsvpSettingsSubmit = (values: RsvpSettingsFormValues) => {
    saveConfigMutation.mutate({
      rsvpEmail: values.rsvpEmail,
      rsvpDeadlineDate: values.rsvpDeadlineDate,
    });
  };

  const onWebsiteSettingsSubmit = (values: WebsiteSettingsFormValues) => {
    saveConfigMutation.mutate({
      siteTitle: values.siteTitle,
      welcomeMessage: values.welcomeMessage,
      footerMessage: values.footerMessage || '',
    });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-3xl font-bold">Impostazioni</h1>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-4">
            <TabsTrigger value="wedding-details" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden md:inline">Dettagli Matrimonio</span>
              <span className="md:hidden">Dettagli</span>
            </TabsTrigger>
            <TabsTrigger value="our-story" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              <span className="hidden md:inline">La Nostra Storia</span>
              <span className="md:hidden">Storia</span>
            </TabsTrigger>
            <TabsTrigger value="rsvp-settings" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden md:inline">Impostazioni RSVP</span>
              <span className="md:hidden">RSVP</span>
            </TabsTrigger>
            <TabsTrigger value="website-settings" className="flex items-center gap-2">
              <Settings2 className="h-4 w-4" />
              <span className="hidden md:inline">Impostazioni Sito</span>
              <span className="md:hidden">Sito</span>
            </TabsTrigger>
          </TabsList>

          {isLoading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <>
              <TabsContent value="wedding-details">
                <Card>
                  <CardHeader>
                    <CardTitle>Dettagli Matrimonio</CardTitle>
                    <CardDescription>
                      Informazioni principali sulla coppia e sulla data del matrimonio
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...weddingDetailsForm}>
                      <form 
                        onSubmit={weddingDetailsForm.handleSubmit(onWeddingDetailsSubmit)} 
                        className="space-y-6"
                      >
                        <div className="grid gap-4 md:grid-cols-2">
                          <div className="space-y-4">
                            <div className="flex items-center gap-2 mb-2">
                              <User className="h-5 w-5 text-primary" />
                              <h3 className="text-lg font-medium">Sposo</h3>
                            </div>
                            <FormField
                              control={weddingDetailsForm.control}
                              name="groomFirstName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Nome*</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Nome" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={weddingDetailsForm.control}
                              name="groomLastName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Cognome*</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Cognome" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="space-y-4">
                            <div className="flex items-center gap-2 mb-2">
                              <User className="h-5 w-5 text-primary" />
                              <h3 className="text-lg font-medium">Sposa</h3>
                            </div>
                            <FormField
                              control={weddingDetailsForm.control}
                              name="brideFirstName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Nome*</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Nome" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={weddingDetailsForm.control}
                              name="brideLastName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Cognome*</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Cognome" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>

                        <div className="pt-4 border-t">
                          <div className="flex items-center gap-2 mb-4">
                            <Calendar className="h-5 w-5 text-primary" />
                            <h3 className="text-lg font-medium">Data del Matrimonio</h3>
                          </div>
                          <FormField
                            control={weddingDetailsForm.control}
                            name="date"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Data*</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <FormDescription>
                                  La data verrà mostrata in tutto il sito
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <Button 
                          type="submit" 
                          className="w-full md:w-auto"
                          disabled={saveConfigMutation.isPending}
                        >
                          {saveConfigMutation.isPending && (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          )}
                          Salva Dettagli
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="our-story">
                <Card>
                  <CardHeader>
                    <CardTitle>La Nostra Storia</CardTitle>
                    <CardDescription>
                      Racconta la vostra storia d'amore
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...ourStoryForm}>
                      <form 
                        onSubmit={ourStoryForm.handleSubmit(onOurStorySubmit)} 
                        className="space-y-6"
                      >
                        <div className="grid gap-4 md:grid-cols-2">
                          <FormField
                            control={ourStoryForm.control}
                            name="meetDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Data di quando vi siete conosciuti</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} value={field.value || ''} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={ourStoryForm.control}
                            name="proposalDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Data della proposta</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} value={field.value || ''} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={ourStoryForm.control}
                          name="storyText"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>La vostra storia*</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Raccontate la vostra storia..." 
                                  className="min-h-[200px]" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Raccontate come vi siete conosciuti, la proposta e altri momenti speciali
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <Button 
                          type="submit" 
                          className="w-full md:w-auto"
                          disabled={saveConfigMutation.isPending}
                        >
                          {saveConfigMutation.isPending && (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          )}
                          Salva Storia
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="rsvp-settings">
                <Card>
                  <CardHeader>
                    <CardTitle>Impostazioni RSVP</CardTitle>
                    <CardDescription>
                      Configura le impostazioni per le risposte degli invitati
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...rsvpSettingsForm}>
                      <form 
                        onSubmit={rsvpSettingsForm.handleSubmit(onRsvpSettingsSubmit)} 
                        className="space-y-6"
                      >
                        <FormField
                          control={rsvpSettingsForm.control}
                          name="rsvpEmail"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email per notifiche RSVP*</FormLabel>
                              <FormControl>
                                <Input 
                                  type="email" 
                                  placeholder="tua@email.com" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Riceverai notifiche a questa email quando gli invitati rispondono
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={rsvpSettingsForm.control}
                          name="rsvpDeadlineDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Data limite per rispondere*</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormDescription>
                                Gli invitati devono rispondere entro questa data
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <Button 
                          type="submit" 
                          className="w-full md:w-auto"
                          disabled={saveConfigMutation.isPending}
                        >
                          {saveConfigMutation.isPending && (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          )}
                          Salva Impostazioni RSVP
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="website-settings">
                <Card>
                  <CardHeader>
                    <CardTitle>Impostazioni del Sito</CardTitle>
                    <CardDescription>
                      Personalizza le impostazioni generali del sito web
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...websiteSettingsForm}>
                      <form 
                        onSubmit={websiteSettingsForm.handleSubmit(onWebsiteSettingsSubmit)} 
                        className="space-y-6"
                      >
                        <FormField
                          control={websiteSettingsForm.control}
                          name="siteTitle"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Titolo del sito*</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Matrimonio di Fabio & Denise" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Questo titolo apparirà nella scheda del browser
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={websiteSettingsForm.control}
                          name="welcomeMessage"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Messaggio di benvenuto*</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Benvenuti nel nostro sito di matrimonio..." 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Messaggio mostrato nella pagina iniziale
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={websiteSettingsForm.control}
                          name="footerMessage"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Messaggio di footer</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="© 2025 Fabio & Denise" 
                                  {...field} 
                                  value={field.value || ''}
                                />
                              </FormControl>
                              <FormDescription>
                                Messaggio mostrato nel footer del sito
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <Button 
                          type="submit" 
                          className="w-full md:w-auto"
                          disabled={saveConfigMutation.isPending}
                        >
                          {saveConfigMutation.isPending && (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          )}
                          Salva Impostazioni Sito
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </>
          )}
        </Tabs>
      </div>
    </AdminLayout>
  );
}