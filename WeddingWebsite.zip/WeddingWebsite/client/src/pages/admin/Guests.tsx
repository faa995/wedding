import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import AdminLayout from './components/AdminLayout';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Check,
  Loader2,
  Pencil,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const guestFormSchema = z.object({
  name: z.string().min(1, "Il nome è obbligatorio"),
  email: z.string().email("Inserisci un'email valida").nullable().optional(),
  phone: z.string().nullable().optional(),
  category: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
});

type GuestFormValues = z.infer<typeof guestFormSchema>;

export default function GuestsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editingGuest, setEditingGuest] = useState<any>(null);
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [confirmationFilter, setConfirmationFilter] = useState<string | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: guests, isLoading } = useQuery({
    queryKey: ['/api/admin/guests'],
  });

  const { data: categories } = useQuery({
    queryKey: ['/api/admin/guests/categories'],
    queryFn: async () => {
      // Estrai categorie uniche dai dati degli ospiti
      if (!guests) return [];
      const uniqueCategories = new Set<string>();
      guests.forEach((guest: any) => {
        if (guest.category) uniqueCategories.add(guest.category);
      });
      return Array.from(uniqueCategories);
    },
    enabled: !!guests,
  });

  const addGuestMutation = useMutation({
    mutationFn: async (guest: GuestFormValues) => {
      const response = await apiRequest('/api/admin/guests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(guest),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'aggiunta dell\'ospite');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/guests'] });
      toast({
        title: 'Ospite aggiunto',
        description: 'L\'ospite è stato aggiunto con successo.',
      });
      setAddDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante l\'aggiunta dell\'ospite',
        variant: 'destructive',
      });
    },
  });

  const updateGuestMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: GuestFormValues }) => {
      const response = await apiRequest(`/api/guests/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'aggiornamento dell\'ospite');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/guests'] });
      toast({
        title: 'Ospite aggiornato',
        description: 'L\'ospite è stato aggiornato con successo.',
      });
      setEditingGuest(null);
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante l\'aggiornamento dell\'ospite',
        variant: 'destructive',
      });
    },
  });

  const deleteGuestMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest(`/api/guests/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'eliminazione dell\'ospite');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/guests'] });
      toast({
        title: 'Ospite eliminato',
        description: 'L\'ospite è stato eliminato con successo.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante l\'eliminazione dell\'ospite',
        variant: 'destructive',
      });
    },
  });

  const toggleConfirmationMutation = useMutation({
    mutationFn: async ({ id, isConfirmed }: { id: number; isConfirmed: boolean }) => {
      const response = await apiRequest(`/api/guests/${id}/confirm`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isConfirmed }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'aggiornamento della conferma');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/guests'] });
    },
    onError: (error) => {
      toast({
        title: 'Errore',
        description: error instanceof Error ? error.message : 'Errore durante l\'aggiornamento della conferma',
        variant: 'destructive',
      });
    },
  });

  const form = useForm<GuestFormValues>({
    resolver: zodResolver(guestFormSchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
      category: '',
      notes: '',
    },
  });

  React.useEffect(() => {
    if (editingGuest) {
      form.reset({
        name: editingGuest.name,
        email: editingGuest.email || '',
        phone: editingGuest.phone || '',
        category: editingGuest.category || '',
        notes: editingGuest.notes || '',
      });
    } else {
      form.reset({
        name: '',
        email: '',
        phone: '',
        category: '',
        notes: '',
      });
    }
  }, [editingGuest, form]);

  const onSubmit = (values: GuestFormValues) => {
    if (editingGuest) {
      updateGuestMutation.mutate({ id: editingGuest.id, data: values });
    } else {
      addGuestMutation.mutate(values);
    }
  };

  const filteredGuests = guests
    ? guests.filter((guest: any) => {
        const matchesSearch =
          !searchQuery ||
          guest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (guest.email && guest.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (guest.phone && guest.phone.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesCategory = !categoryFilter || guest.category === categoryFilter;
        
        const matchesConfirmation = 
          !confirmationFilter || 
          (confirmationFilter === 'confirmed' && guest.isConfirmed) ||
          (confirmationFilter === 'unconfirmed' && !guest.isConfirmed);

        return matchesSearch && matchesCategory && matchesConfirmation;
      })
    : [];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-3xl font-bold">Invitati</h1>
          <div className="mt-2 sm:mt-0">
            <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Aggiungi Invitato
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Aggiungi un nuovo invitato</DialogTitle>
                  <DialogDescription>
                    Inserisci i dettagli del nuovo invitato
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome*</FormLabel>
                          <FormControl>
                            <Input placeholder="Nome completo" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Email" 
                              type="email" 
                              {...field} 
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Telefono</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Numero di telefono" 
                              {...field} 
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Categoria</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Amici, Famiglia, Lavoro, ecc." 
                              {...field} 
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormDescription>
                            Classifica l'invitato per organizzazione
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Note</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Note aggiuntive" 
                              {...field} 
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={addGuestMutation.isPending || updateGuestMutation.isPending}
                      >
                        {(addGuestMutation.isPending || updateGuestMutation.isPending) && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        {editingGuest ? 'Aggiorna' : 'Aggiungi'}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista Invitati</CardTitle>
            <CardDescription>
              Gestisci la lista degli invitati al matrimonio
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Cerca per nome, email o telefono..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <Select
                value={categoryFilter || ''}
                onValueChange={(value) => setCategoryFilter(value || null)}
              >
                <SelectTrigger className="w-full md:w-[180px]">
                  <SelectValue placeholder="Tutte le categorie" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Tutte le categorie</SelectItem>
                  {categories?.map((category: string) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select
                value={confirmationFilter || ''}
                onValueChange={(value) => setConfirmationFilter(value || null)}
              >
                <SelectTrigger className="w-full md:w-[180px]">
                  <SelectValue placeholder="Stato conferma" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Tutti gli stati</SelectItem>
                  <SelectItem value="confirmed">Confermati</SelectItem>
                  <SelectItem value="unconfirmed">Non confermati</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {isLoading ? (
              <div className="flex items-center justify-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : filteredGuests.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                Nessun invitato trovato
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Contatto</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Stato</TableHead>
                      <TableHead className="text-right">Azioni</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredGuests.map((guest: any) => (
                      <TableRow key={guest.id}>
                        <TableCell className="font-medium">{guest.name}</TableCell>
                        <TableCell>
                          {guest.email && (
                            <div>{guest.email}</div>
                          )}
                          {guest.phone && (
                            <div className="text-sm text-muted-foreground">{guest.phone}</div>
                          )}
                        </TableCell>
                        <TableCell>
                          {guest.category ? (
                            <Badge variant="outline">{guest.category}</Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={guest.isConfirmed ? "default" : "secondary"}
                            className="cursor-pointer"
                            onClick={() => 
                              toggleConfirmationMutation.mutate({ 
                                id: guest.id, 
                                isConfirmed: !guest.isConfirmed 
                              })
                            }
                          >
                            {toggleConfirmationMutation.isPending && 
                             toggleConfirmationMutation.variables?.id === guest.id ? (
                              <Loader2 className="h-3 w-3 animate-spin mr-1" />
                            ) : (
                              guest.isConfirmed ? <Check className="h-3 w-3 mr-1" /> : <X className="h-3 w-3 mr-1" />
                            )}
                            {guest.isConfirmed ? "Confermato" : "Non confermato"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setEditingGuest(guest);
                                setAddDialogOpen(true);
                              }}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteGuestMutation.mutate(guest.id)}
                              disabled={deleteGuestMutation.isPending}
                            >
                              {deleteGuestMutation.isPending && 
                               deleteGuestMutation.variables === guest.id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <Trash2 className="h-4 w-4 text-destructive" />
                              )}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <div className="text-xs text-muted-foreground">
              Totale: {filteredGuests.length} invitati
              {confirmationFilter === 'confirmed' && (
                <span> (Confermati: {filteredGuests.filter((g: any) => g.isConfirmed).length})</span>
              )}
              {confirmationFilter === 'unconfirmed' && (
                <span> (Non confermati: {filteredGuests.filter((g: any) => !g.isConfirmed).length})</span>
              )}
            </div>
          </CardFooter>
        </Card>
      </div>
    </AdminLayout>
  );
}