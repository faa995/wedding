import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import OurStory from "@/components/OurStory";
import EventDetails from "@/components/EventDetails";
import Gallery from "@/components/Gallery";
import TravelInfo from "@/components/TravelInfo";
import Registry from "@/components/Registry";
import RsvpForm from "@/components/RsvpForm";
import Footer from "@/components/Footer";
import { colors } from "@/lib/utils";

export default function Home() {
  // Wedding details that can be reused across components
  const weddingDetails = {
    bridesName: "Denise",
    groomsName: "Fabio",
    weddingDate: new Date("2024-06-15T15:00:00"),
    venue: "Villa Belvedere",
    location: "Toscana"
  };
  
  return (
    <div className="bg-[#faf7f2] text-[#333333]">
      <Navbar />
      
      <Hero 
        bridesName={weddingDetails.bridesName}
        groomsName={weddingDetails.groomsName}
        weddingDate={weddingDetails.weddingDate}
        venue={weddingDetails.venue}
        location={weddingDetails.location}
      />
      
      <OurStory />
      
      <EventDetails 
        weddingDate={weddingDetails.weddingDate}
      />
      
      <Gallery />
      
      <TravelInfo />
      
      <Registry />
      
      <RsvpForm 
        weddingDate={weddingDetails.weddingDate}
      />
      
      <Footer 
        bridesName={weddingDetails.bridesName}
        groomsName={weddingDetails.groomsName}
        weddingDate={weddingDetails.weddingDate}
      />
    </div>
  );
}
