import { useEffect } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import OurStory from "@/components/OurStory";
import EventDetails from "@/components/EventDetails";
import Gallery from "@/components/Gallery";
import TravelInfo from "@/components/TravelInfo";
import Registry from "@/components/Registry";
import RsvpForm from "@/components/RsvpForm";
import Footer from "@/components/Footer";

export default function Home() {
  // Scroll to the top when the component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-secondary">
      <Header />
      <Hero />
      <OurStory />
      <EventDetails />
      <Gallery />
      <TravelInfo />
      <Registry />
      <RsvpForm />
      <Footer />
    </div>
  );
}
