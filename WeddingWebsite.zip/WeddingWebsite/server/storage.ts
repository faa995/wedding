import {
  type Rsvp, type InsertRsvp,
  type User, type InsertUser,
  type SiteConfig, type InsertSiteConfig,
  type GuestList, type InsertGuestList,
  type Event, type InsertEvent,
  type Gallery, type InsertGallery
} from "@shared/schema";
import bcrypt from "bcrypt";

export interface IStorage {
  // RSVP methods
  getAllRsvps(): Promise<Rsvp[]>;
  getRsvp(id: number): Promise<Rsvp | undefined>;
  getRsvpByEmail(email: string): Promise<Rsvp | undefined>;
  createRsvp(rsvp: InsertRsvp): Promise<Rsvp>;
  
  // User methods
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Site config methods
  getAllConfig(): Promise<SiteConfig[]>;
  getConfigByKey(key: string): Promise<SiteConfig | undefined>;
  setConfig(key: string, value: string): Promise<SiteConfig>;
  
  // Guest list methods
  getAllGuests(): Promise<GuestList[]>;
  getGuest(id: number): Promise<GuestList | undefined>;
  createGuest(guest: InsertGuestList): Promise<GuestList>;
  updateGuest(id: number, guest: Partial<InsertGuestList>): Promise<GuestList | undefined>;
  deleteGuest(id: number): Promise<boolean>;
  markGuestConfirmed(id: number, confirmed: boolean): Promise<GuestList | undefined>;
  
  // Event methods
  getAllEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<boolean>;
  
  // Gallery methods
  getAllGalleryItems(): Promise<Gallery[]>;
  getGalleryItem(id: number): Promise<Gallery | undefined>;
  createGalleryItem(item: InsertGallery): Promise<Gallery>;
  updateGalleryItem(id: number, item: Partial<InsertGallery>): Promise<Gallery | undefined>;
  deleteGalleryItem(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private rsvps: Map<number, Rsvp>;
  private users: Map<number, User>;
  private config: Map<string, SiteConfig>;
  private guests: Map<number, GuestList>;
  private events: Map<number, Event>;
  private gallery: Map<number, Gallery>;
  
  private rsvpId: number;
  private userId: number;
  private configId: number;
  private guestId: number;
  private eventId: number;
  private galleryId: number;

  constructor() {
    this.rsvps = new Map();
    this.users = new Map();
    this.config = new Map();
    this.guests = new Map();
    this.events = new Map();
    this.gallery = new Map();
    
    this.rsvpId = 1;
    this.userId = 1;
    this.configId = 1;
    this.guestId = 1;
    this.eventId = 1;
    this.galleryId = 1;
    
    // Initialize with default admin user
    this.createDefaultAdmin();
    
    // Initialize with default site configuration
    this.initDefaultConfig();
  }
  
  private async createDefaultAdmin() {
    const adminUsername = "admin";
    const adminPassword = "admin"; // Default password (should be changed)
    
    // Check if admin user already exists
    const existingAdmin = await this.getUserByUsername(adminUsername);
    if (!existingAdmin) {
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(adminPassword, saltRounds);
      
      const id = this.userId++;
      const now = new Date();
      
      const user: User = {
        id,
        username: adminUsername,
        passwordHash,
        createdAt: now
      };
      
      this.users.set(id, user);
    }
  }
  
  private initDefaultConfig() {
    const defaultConfig = [
      { key: "coupleNames", value: "Fabio & Denise" },
      { key: "weddingDate", value: "2025-12-21T16:00:00" },
      { key: "venueName", value: "Tenuta Donna Fausta" },
      { key: "venueAddress", value: "Via Castello, 81051 Roccaromana CE" },
      { key: "logoText", value: "F&D" },
      { key: "primaryColor", value: "#c9a57c" },
      { key: "secondaryColor", value: "#85714D" },
      { key: "contactEmail", value: "fabiorosella95@gmail.com" }
    ];
    
    defaultConfig.forEach(cfg => {
      if (!this.config.has(cfg.key)) {
        const id = this.configId++;
        const now = new Date();
        
        const configItem: SiteConfig = {
          id,
          key: cfg.key,
          value: cfg.value,
          updatedAt: now
        };
        
        this.config.set(cfg.key, configItem);
      }
    });
  }

  // RSVP Methods
  async getAllRsvps(): Promise<Rsvp[]> {
    return Array.from(this.rsvps.values());
  }

  async getRsvp(id: number): Promise<Rsvp | undefined> {
    return this.rsvps.get(id);
  }

  async getRsvpByEmail(email: string): Promise<Rsvp | undefined> {
    return Array.from(this.rsvps.values()).find(
      (rsvp) => rsvp.email === email,
    );
  }

  async createRsvp(insertRsvp: InsertRsvp): Promise<Rsvp> {
    const id = this.rsvpId++;
    const now = new Date();
    const rsvp: Rsvp = { 
      ...insertRsvp, 
      id, 
      createdAt: now,
      phone: insertRsvp.phone || null,
      dietary: insertRsvp.dietary || null,
      message: insertRsvp.message || null,
      guestNames: insertRsvp.guestNames || [],
      attending: Array.isArray(insertRsvp.attending) ? insertRsvp.attending : []
    };
    this.rsvps.set(id, rsvp);
    return rsvp;
  }
  
  // User Methods
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const { username, password } = insertUser;
    
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);
    
    const id = this.userId++;
    const now = new Date();
    
    const user: User = {
      id,
      username,
      passwordHash,
      createdAt: now
    };
    
    this.users.set(id, user);
    return user;
  }
  
  // Config Methods
  async getAllConfig(): Promise<SiteConfig[]> {
    return Array.from(this.config.values());
  }
  
  async getConfigByKey(key: string): Promise<SiteConfig | undefined> {
    return this.config.get(key);
  }
  
  async setConfig(key: string, value: string): Promise<SiteConfig> {
    const now = new Date();
    
    // Update if exists
    if (this.config.has(key)) {
      const existingConfig = this.config.get(key)!;
      const updatedConfig: SiteConfig = {
        ...existingConfig,
        value,
        updatedAt: now
      };
      
      this.config.set(key, updatedConfig);
      return updatedConfig;
    }
    
    // Create new if doesn't exist
    const id = this.configId++;
    const newConfig: SiteConfig = {
      id,
      key,
      value,
      updatedAt: now
    };
    
    this.config.set(key, newConfig);
    return newConfig;
  }
  
  // Guest Methods
  async getAllGuests(): Promise<GuestList[]> {
    return Array.from(this.guests.values());
  }
  
  async getGuest(id: number): Promise<GuestList | undefined> {
    return this.guests.get(id);
  }
  
  async createGuest(insertGuest: InsertGuestList): Promise<GuestList> {
    const id = this.guestId++;
    const now = new Date();
    
    const guest: GuestList = {
      ...insertGuest,
      id,
      email: insertGuest.email || null,
      phone: insertGuest.phone || null,
      category: insertGuest.category || null,
      notes: insertGuest.notes || null,
      isConfirmed: false,
      createdAt: now
    };
    
    this.guests.set(id, guest);
    return guest;
  }
  
  async updateGuest(id: number, updateData: Partial<InsertGuestList>): Promise<GuestList | undefined> {
    const existing = this.guests.get(id);
    if (!existing) return undefined;
    
    const updated: GuestList = {
      ...existing,
      ...updateData
    };
    
    this.guests.set(id, updated);
    return updated;
  }
  
  async deleteGuest(id: number): Promise<boolean> {
    return this.guests.delete(id);
  }
  
  async markGuestConfirmed(id: number, confirmed: boolean): Promise<GuestList | undefined> {
    const existing = this.guests.get(id);
    if (!existing) return undefined;
    
    const updated: GuestList = {
      ...existing,
      isConfirmed: confirmed
    };
    
    this.guests.set(id, updated);
    return updated;
  }
  
  // Event Methods
  async getAllEvents(): Promise<Event[]> {
    return Array.from(this.events.values())
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }
  
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }
  
  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.eventId++;
    const now = new Date();
    
    const event: Event = {
      ...insertEvent,
      id,
      description: insertEvent.description || null,
      endTime: insertEvent.endTime || null,
      location: insertEvent.location || null,
      order: insertEvent.order || 0,
      createdAt: now
    };
    
    this.events.set(id, event);
    return event;
  }
  
  async updateEvent(id: number, updateData: Partial<InsertEvent>): Promise<Event | undefined> {
    const existing = this.events.get(id);
    if (!existing) return undefined;
    
    const updated: Event = {
      ...existing,
      ...updateData
    };
    
    this.events.set(id, updated);
    return updated;
  }
  
  async deleteEvent(id: number): Promise<boolean> {
    return this.events.delete(id);
  }
  
  // Gallery Methods
  async getAllGalleryItems(): Promise<Gallery[]> {
    return Array.from(this.gallery.values())
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }
  
  async getGalleryItem(id: number): Promise<Gallery | undefined> {
    return this.gallery.get(id);
  }
  
  async createGalleryItem(insertItem: InsertGallery): Promise<Gallery> {
    const id = this.galleryId++;
    const now = new Date();
    
    const item: Gallery = {
      ...insertItem,
      id,
      title: insertItem.title || null,
      description: insertItem.description || null,
      order: insertItem.order || 0,
      createdAt: now
    };
    
    this.gallery.set(id, item);
    return item;
  }
  
  async updateGalleryItem(id: number, updateData: Partial<InsertGallery>): Promise<Gallery | undefined> {
    const existing = this.gallery.get(id);
    if (!existing) return undefined;
    
    const updated: Gallery = {
      ...existing,
      ...updateData
    };
    
    this.gallery.set(id, updated);
    return updated;
  }
  
  async deleteGalleryItem(id: number): Promise<boolean> {
    return this.gallery.delete(id);
  }
}

export const storage = new MemStorage();
