import nodemailer from 'nodemailer';
import { Rsvp } from '@shared/schema';

// In produzione, userebbe le credenziali SMTP reali
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER || '',
    pass: process.env.EMAIL_PASSWORD || ''
  }
});

export async function sendRsvpNotification(rsvp: Rsvp, to: string): Promise<boolean> {
  try {
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASSWORD) {
      console.warn('Email credentials not configured. Skipping email notification.');
      return false;
    }

    // Costruisce l'elenco dei partecipanti
    const guestsList = rsvp.guestNames && rsvp.guestNames.length > 0 
      ? `<p><strong>Ospiti aggiuntivi:</strong> ${rsvp.guestNames.join(', ')}</p>` 
      : '';

    // Costruisce l'elenco degli eventi a cui parteciperanno
    const attendingEvents = rsvp.attending.map(event => {
      switch(event) {
        case 'ceremony': return 'Cerimonia';
        case 'reception': return 'Ricevimento';
        case 'afterparty': return 'After Party';
        default: return event;
      }
    }).join(', ');

    // Compone l'email
    await transporter.sendMail({
      from: `"Matrimonio Fabio & Denise" <${process.env.EMAIL_USER}>`,
      to,
      subject: `Nuova RSVP da ${rsvp.name}`,
      html: `
        <h2>Nuova RSVP ricevuta!</h2>
        <p><strong>Nome:</strong> ${rsvp.name}</p>
        <p><strong>Email:</strong> ${rsvp.email}</p>
        <p><strong>Telefono:</strong> ${rsvp.phone || 'Non specificato'}</p>
        <p><strong>Numero di ospiti:</strong> ${rsvp.guests}</p>
        ${guestsList}
        <p><strong>Partecipa a:</strong> ${attendingEvents}</p>
        <p><strong>Esigenze alimentari:</strong> ${rsvp.dietary || 'Nessuna'}</p>
        <p><strong>Messaggio:</strong> ${rsvp.message || 'Nessun messaggio'}</p>
        <hr>
        <p>Ricevuto il: ${new Date(rsvp.createdAt).toLocaleString('it-IT')}</p>
      `
    });
    
    return true;
  } catch (error) {
    console.error('Errore durante l\'invio dell\'email di notifica RSVP:', error);
    return false;
  }
}

export async function testEmailConnection(): Promise<boolean> {
  try {
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASSWORD) {
      console.warn('Email credentials not configured. Cannot test connection.');
      return false;
    }

    await transporter.verify();
    return true;
  } catch (error) {
    console.error('Email connection test failed:', error);
    return false;
  }
}