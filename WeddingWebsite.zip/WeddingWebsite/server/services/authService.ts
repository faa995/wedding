import bcrypt from 'bcrypt';
import { User } from '@shared/schema';
import { storage } from '../storage';

export async function authenticateUser(username: string, password: string): Promise<User | null> {
  try {
    // Trova l'utente nel database
    const user = await storage.getUserByUsername(username);
    
    // Se l'utente non esiste, ritorna null
    if (!user) {
      return null;
    }
    
    // Verifica la password
    const passwordMatch = await bcrypt.compare(password, user.passwordHash);
    
    // Se la password non corrisponde, ritorna null
    if (!passwordMatch) {
      return null;
    }
    
    // Ritorna l'utente autenticato (senza la password hash)
    return user;
  } catch (error) {
    console.error('Error during authentication:', error);
    return null;
  }
}

export async function changePassword(userId: number, currentPassword: string, newPassword: string): Promise<boolean> {
  try {
    // Implementare quando necessario
    return false;
  } catch (error) {
    console.error('Error changing password:', error);
    return false;
  }
}