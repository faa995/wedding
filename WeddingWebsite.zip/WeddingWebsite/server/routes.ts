import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertRsvpSchema, 
  insertUserSchema, 
  insertGuestListSchema,
  insertEventSchema,
  insertGallerySchema,
  insertSiteConfigSchema
} from "@shared/schema";
import { z } from "zod";
import session from "express-session";
import cookieParser from "cookie-parser";
import { sendRsvpNotification } from "./services/emailService";
import { authenticateUser } from "./services/authService";

// Middleware per verificare se l'utente è autenticato
const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.session && req.session.userId) {
    next();
  } else {
    res.status(401).json({ message: "Non autorizzato" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup middleware
  app.use(cookieParser());
  app.use(session({
    secret: process.env.SESSION_SECRET || 'matrimonio-segreto',
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000 // 24 ore
    }
  }));

  // API routes prefix with /api
  const apiRouter = express.Router();
  const adminRouter = express.Router();

  // =================================================================
  // Public API Routes
  // =================================================================

  // Get site configuration
  apiRouter.get("/config", async (req, res) => {
    try {
      const config = await storage.getAllConfig();
      // Converte l'array di configurazioni in un oggetto per facilità d'uso lato client
      const configObject = config.reduce((acc, item) => {
        acc[item.key] = item.value;
        return acc;
      }, {} as Record<string, string>);
      
      res.json(configObject);
    } catch (error) {
      console.error("Error fetching configuration:", error);
      res.status(500).json({ message: "Failed to fetch configuration" });
    }
  });

  // Get all events
  apiRouter.get("/events", async (req, res) => {
    try {
      const events = await storage.getAllEvents();
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // Get all gallery items
  apiRouter.get("/gallery", async (req, res) => {
    try {
      const gallery = await storage.getAllGalleryItems();
      res.json(gallery);
    } catch (error) {
      console.error("Error fetching gallery:", error);
      res.status(500).json({ message: "Failed to fetch gallery" });
    }
  });

  // Create a new RSVP
  apiRouter.post("/rsvp", async (req, res) => {
    try {
      // Validate the request body
      const validatedData = insertRsvpSchema.parse(req.body);

      // Create the RSVP
      const rsvp = await storage.createRsvp(validatedData);
      
      // Get notification email from config (fallback to hardcoded value if not found)
      const emailConfig = await storage.getConfigByKey("contactEmail");
      const notificationEmail = emailConfig?.value || "fabiorosella95@gmail.com";
      
      // Send email notification
      const emailSent = await sendRsvpNotification(rsvp, notificationEmail);
      
      res.status(201).json({ 
        ...rsvp, 
        emailNotificationSent: emailSent 
      });
    } catch (error) {
      console.error("Error creating RSVP:", error);

      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }

      res.status(500).json({ message: "Failed to create RSVP" });
    }
  });

  // Guest name suggestions (for autocomplete in RSVP form)
  apiRouter.get("/guests/suggestions", async (req, res) => {
    try {
      const { query } = req.query;
      if (!query || typeof query !== 'string') {
        return res.json([]);
      }
      
      const guests = await storage.getAllGuests();
      const suggestions = guests
        .filter(guest => 
          guest.name.toLowerCase().includes(query.toLowerCase())
        )
        .map(guest => ({
          id: guest.id,
          name: guest.name
        }));
      
      res.json(suggestions);
    } catch (error) {
      console.error("Error fetching guest suggestions:", error);
      res.status(500).json({ message: "Failed to fetch guest suggestions" });
    }
  });

  // =================================================================
  // Auth routes
  // =================================================================

  // Login
  apiRouter.post("/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username e password richiesti" });
      }
      
      const user = await authenticateUser(username, password);
      
      if (!user) {
        return res.status(401).json({ message: "Credenziali non valide" });
      }
      
      // Imposta l'utente nella sessione
      req.session.userId = user.id;
      req.session.username = user.username;
      
      res.json({ 
        id: user.id, 
        username: user.username
      });
    } catch (error) {
      console.error("Error during login:", error);
      res.status(500).json({ message: "Errore durante il login" });
    }
  });

  // Logout
  apiRouter.post("/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Errore durante il logout" });
      }
      res.json({ message: "Logout effettuato con successo" });
    });
  });

  // Check auth status
  apiRouter.get("/auth/status", (req, res) => {
    if (req.session && req.session.userId) {
      res.json({ 
        authenticated: true, 
        user: { 
          id: req.session.userId, 
          username: req.session.username 
        }
      });
    } else {
      res.json({ authenticated: false });
    }
  });

  // =================================================================
  // Admin routes (protected)
  // =================================================================

  // Get all RSVPs
  adminRouter.get("/rsvps", async (req, res) => {
    try {
      const rsvps = await storage.getAllRsvps();
      res.json(rsvps);
    } catch (error) {
      console.error("Error fetching RSVPs:", error);
      res.status(500).json({ message: "Failed to fetch RSVPs" });
    }
  });

  // Get a specific RSVP by id
  adminRouter.get("/rsvps/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const rsvp = await storage.getRsvp(id);
      if (!rsvp) {
        return res.status(404).json({ message: "RSVP not found" });
      }

      res.json(rsvp);
    } catch (error) {
      console.error("Error fetching RSVP:", error);
      res.status(500).json({ message: "Failed to fetch RSVP" });
    }
  });

  // Guest List Management
  adminRouter.get("/guests", async (req, res) => {
    try {
      const guests = await storage.getAllGuests();
      res.json(guests);
    } catch (error) {
      console.error("Error fetching guests:", error);
      res.status(500).json({ message: "Failed to fetch guests" });
    }
  });

  adminRouter.post("/guests", async (req, res) => {
    try {
      const validatedData = insertGuestListSchema.parse(req.body);
      const guest = await storage.createGuest(validatedData);
      res.status(201).json(guest);
    } catch (error) {
      console.error("Error creating guest:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create guest" });
    }
  });

  adminRouter.put("/guests/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const updateData = req.body;
      const guest = await storage.updateGuest(id, updateData);
      
      if (!guest) {
        return res.status(404).json({ message: "Guest not found" });
      }

      res.json(guest);
    } catch (error) {
      console.error("Error updating guest:", error);
      res.status(500).json({ message: "Failed to update guest" });
    }
  });

  adminRouter.delete("/guests/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const success = await storage.deleteGuest(id);
      
      if (!success) {
        return res.status(404).json({ message: "Guest not found" });
      }

      res.json({ message: "Guest deleted successfully" });
    } catch (error) {
      console.error("Error deleting guest:", error);
      res.status(500).json({ message: "Failed to delete guest" });
    }
  });

  // Event Management
  adminRouter.post("/events", async (req, res) => {
    try {
      const validatedData = insertEventSchema.parse(req.body);
      const event = await storage.createEvent(validatedData);
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating event:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create event" });
    }
  });

  adminRouter.put("/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const updateData = req.body;
      const event = await storage.updateEvent(id, updateData);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      res.json(event);
    } catch (error) {
      console.error("Error updating event:", error);
      res.status(500).json({ message: "Failed to update event" });
    }
  });

  adminRouter.delete("/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const success = await storage.deleteEvent(id);
      
      if (!success) {
        return res.status(404).json({ message: "Event not found" });
      }

      res.json({ message: "Event deleted successfully" });
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ message: "Failed to delete event" });
    }
  });

  // Gallery Management
  adminRouter.post("/gallery", async (req, res) => {
    try {
      const validatedData = insertGallerySchema.parse(req.body);
      const galleryItem = await storage.createGalleryItem(validatedData);
      res.status(201).json(galleryItem);
    } catch (error) {
      console.error("Error creating gallery item:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create gallery item" });
    }
  });

  adminRouter.put("/gallery/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const updateData = req.body;
      const galleryItem = await storage.updateGalleryItem(id, updateData);
      
      if (!galleryItem) {
        return res.status(404).json({ message: "Gallery item not found" });
      }

      res.json(galleryItem);
    } catch (error) {
      console.error("Error updating gallery item:", error);
      res.status(500).json({ message: "Failed to update gallery item" });
    }
  });

  adminRouter.delete("/gallery/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const success = await storage.deleteGalleryItem(id);
      
      if (!success) {
        return res.status(404).json({ message: "Gallery item not found" });
      }

      res.json({ message: "Gallery item deleted successfully" });
    } catch (error) {
      console.error("Error deleting gallery item:", error);
      res.status(500).json({ message: "Failed to delete gallery item" });
    }
  });

  // Site Configuration Management
  adminRouter.put("/config/:key", async (req, res) => {
    try {
      const { key } = req.params;
      const { value } = req.body;
      
      if (!key || value === undefined) {
        return res.status(400).json({ message: "Key and value are required" });
      }
      
      const config = await storage.setConfig(key, value);
      res.json(config);
    } catch (error) {
      console.error("Error updating config:", error);
      res.status(500).json({ message: "Failed to update config" });
    }
  });

  // Register all routes
  app.use("/api", apiRouter);
  app.use("/api/admin", isAuthenticated, adminRouter); // Applica il middleware di autenticazione

  const httpServer = createServer(app);

  return httpServer;
}
